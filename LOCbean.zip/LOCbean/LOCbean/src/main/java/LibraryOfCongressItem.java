package servlet;
public class LibraryOfCongressItem {

public String title;
public String date;
public String contributor;



}