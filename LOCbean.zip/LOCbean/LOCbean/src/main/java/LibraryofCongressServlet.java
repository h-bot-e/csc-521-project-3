/*
 * @(#)LibaryofCongressServlet.java	1.00 
 * Inspired by Snoopservlet
 * Author: Haris Bhatti
 * Copyright (c) 1995-1997 Sun Microsystems, Inc. All Rights Reserved.
 * 
 */
package servlet;


import java.io.*;
import java.util.*;

import javax.servlet.*;
import java.net.URL;
import java.net.*;
import javax.servlet.http.*;
import java.util.Map.*;




import java.sql.*;

/**
 * Library of Congress servlet. This servlet is called by index.html
 * It handles many functions including accessing website data via a querystring
 * that users can modify on the front page with dropdown menus.
 *
 * @version 	1.20
 * @author 	Haris Bhatti + Various, based on SnoopServlet
 */
public
class LibraryofCongressServlet extends HttpServlet {




/*

    public void doGet (HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException
    {
	PrintWriter	out;

	res.setContentType("text/html");
	out = res.getWriter ();


	String cookieName = "biscuit";
	Cookie cookies [] = req.getCookies ();
	Cookie myCookie = null;
	if (cookies != null) {
	  for (int i = 0; i < cookies.length; i++) {
	    if (cookies [i].getName().equals (cookieName)) {
	      myCookie = cookies[i];
	      break;
	    }
	  }
	}
	
	String paramyear = req.getParameterValues("years")[0];
	String paramcountry = req.getParameterValues("country")[0];
	String parampartof = req.getParameterValues("partof")[0];
	String username="Your&nbsplast&nbspsearch&nbspwas&nbspfor&nbspthe&nbspyear&nbsp" + paramyear+ "&nbspthe&nbspEnd&nbspcountry&nbspof&nbsp" + paramcountry + "&nbspand&nbspwas&nbsppart&nbspof&nbspthe&nbspcollection&nbsp" + parampartof;
	if(username==null) username="";
	Cookie cookie = new Cookie ("biscuit",username);
	cookie.setMaxAge(365 * 24 * 60 * 60);
	res.addCookie(cookie);
	
	


	out.println("<html>");
	out.println("");
	out.println("");
	out.println(myCookie.getValue());
	
	
	//out.print("<header>Queries: </header>");

Enumeration TheList = req.getHeaderNames();
TheList = req.getParameterNames();
String[] parameters = new String[3];

//int j = 0;
int j = 0;
if (TheList.hasMoreElements())
{
    while (TheList.hasMoreElements())
    {
        String element = (String)TheList.nextElement();
        parameters[j] = req.getParameter(element);
		//out.print("<header>"+parameters[j]+"</header>");
		//out.print("<h1>j:"+j+", parameters:"+parameters[j]+"</h1>");
		//out.print("<h1>Films made in "+parameters[0]+", in the country of "+parameters[1]+" and part of the "+parameters[2]+" collection</h1>");
        j++;
		
		
    }
	
	//out.print("<h1>Films made in "+parameters[0]+", in the country of "+parameters[1]+" and part of the "+parameters[2]+" collection</h1>");
}


	int year = Integer.parseInt(parameters[0]);
//	char country = Integer.parseInt(parameters[0]);
	
//	HashMap<String, LibraryOfCongressItem>webdata = GiveMeWeb(25, year, parameters[1]);
//	HashMap<String, LibraryOfCongressItem>webdata = GiveMeWeb(25, year, parameters[1]);
//	HashMap<String, LibraryOfCongressItem>webdata = GiveMeWeb(150, year, parameters[1], parameters[2]);
//	LibraryOfCongressItem selecteditem = webdata.get(req.getParameter("TitleButtonGroup"));
	
	
	
//	out.println(webdata);
	

//	out.println("Title: " + selecteditem.title);
//	out.println("<br>");
//	out.println("Contributors: " + selecteditem.contributor);
//	out.println("<br>");
//	out.println("Year: " + selecteditem.date);
	
	
    }
	
	*/
	
	
	/**

    private void print (PrintWriter out, String name, String value)
    {
	out.print(" " + name + ": ");
	out.println(value == null ? "&lt;none&gt;" : value);
    }

    private void print (PrintWriter out, String name, int value)
    {
	out.print(" " + name + ": ");
	if (value == -1) {
	    out.println("&lt;none&gt;");
	} else {
	    out.println(value);		
	}
	*/
	
	
	

	
 
 static String format(String s){
	 /**
	 s = s.replaceAll("\n", "");
	 s = s.replaceAll("\\<.*?\\>", "");
	 s = s.replaceAll("&#39;", "'");
	 s = s.replaceAll(", ", "\n");
	 //s = s.replaceAll("{ ", "");
	 s = s.replaceAll("  ", "");
	 s = s.replaceAll(", ", "");
	 
	// s = s.replaceAll("=LibraryOfCongressItem", "");
	 */
	//s = s.replaceAll("\n", "");
	//s = s.replaceAll("<(.|\\n)+?>", "<br>");
    s = s.replaceAll("LibraryOfCongressItem", "");
	s = s.replaceAll(" '>", " --> <br>");
	s = s.replaceAll("</a>", " <!-- ");
	s = s.replaceAll("<a ", " <!-- ");
	s = s.replaceAll(" /", "");
	//s = s.replaceAll("\n", "");
	//s = s.replaceAll("\\<.*?\\>", "");
	//s = s.replaceAll("&#39;", "'");
	 return s;
	 }
 
 
    public static void GiveMeWeb(String queryurl, javax.servlet.jsp.JspWriter out) throws java.io.IOException{
	
	 
	 
	 URL TheFile=null;

 
     try {	// Set up a URL to the file
       TheFile=new URL(
// This is the query that provides KutztownTable.txt
    //    "https://aa.usno.navy.mil/cgi-bin/aa_rstablew.pl?ID=AA&year=2008&task=0&state=PA&place=Kutztown");
// This provides what we need for now...
	 queryurl);
     //"https://www.loc.gov/film-and-videos/?fa=access-restricted%3Afalse%7Clocation%3Aunited+states%7Cpartof%3Ajazz+on+the+screen+filmography&all=true&sb=title_s&dates=+1977+&st=list&c=100");
	 }
     catch (Exception e) {
       System.err.println("URL Setup failed...");
       e.printStackTrace();
     }
     InputStream s=null;
     try { // Hook up to the file on the server
       s=TheFile.openStream();
     }
     catch (Exception e)  {
       e.printStackTrace();
       System.err.println("!! Stream open failed !!");
     }
     BufferedReader Inf=null;
     try {
       Inf=new BufferedReader(new InputStreamReader(s));
     }
     catch (Exception e){
       e.printStackTrace();
     }
     int next;
     next=Inf.read();
	 StringBuilder html=new StringBuilder();
	 
     while (next>=0) {
       //System.out.print((char)next);
	   html.append((char)next);
       next=Inf.read();
     } 
	 
	 HashMap<String, LibraryOfCongressItem> result = new HashMap<String, LibraryOfCongressItem>();
	 
	 
	//System.out.println("Title\tContributor");
	 
	 //ArrayList<String> titles=giveMeTextBetween(count, html.toString(), "<span class='item-description-title'>", "</span>");
	 
	 int count = 25;
	 
	
	
	 ArrayList<String> titles=giveMeTextBetween(count, html.toString(), "<span class='item-description-title'>", "</span>");
	 //ArrayList<String> titles=giveMeTextBetween(count, html.toString(), "=LibraryOfCongressItem", "=LibraryOfCongressItem");
	 
	 ArrayList<String> contributors=giveMeTextBetween(count, html.toString(), "<strong class='search-results-label'>Contributor:</strong>", "</span>");
	 
	 
	 ArrayList<String> dates=giveMeTextBetween(count, html.toString(), "<strong class='search-results-label'>Date:</strong>", "</span>");
	 
	 
	 
	 for(int i = 0; i < dates.size(); ++i){
		 LibraryOfCongressItem information = new LibraryOfCongressItem();
		 dates.set(i, format(dates.get(i)));
		 contributors.set(i, format(contributors.get(i)));
		 titles.set(i, format(titles.get(i)));
		 information.date = dates.get(i);
		 information.contributor = contributors.get(i);
		 information.title = titles.get(i);
		 
		 result.put(information.title, information);
	//	 result.put(information.title, information);
	//	 result.put(information.contributor, information);
	 //System.out.println(titles.get(i));
	 //System.out.println(contributors.get(i));
	 //System.out.println(dates.get(i));
	 
	 
	 
	 
	 }
	 
	 
	
	
	 
	 out.println(result);
	 //return result;
	 
	 	Statement stmnt;
	
	
	
	
    try {
      Connection con = new OracleConnection().getConnection("hbhat198", "Camper13");
      stmnt=con.createStatement();
      
      // Need to use unique names (Area messed things up!)
      String createString="CREATE TABLE Movies (title VARCHAR2(30), "+
		"contributor VARCHAR2 (70), date NUMBER)";
      stmnt.executeUpdate(createString);
      for (LibraryOfCongressItem item:result.values()) {
        // Form the string representing the insertion statement for this state
        // Note use of ' to delimit strings in the SQL statement
        String StateSQLString = ("INSERT INTO Movies VALUES('" +item.title 
	  + "','" + item.contributor + "'," + item.date + ")");
        stmnt.executeUpdate(StateSQLString);
      } // for
      // We can remove the table (use when table needs to go)
       stmnt.executeUpdate("DROP TABLE Movies");
      stmnt.close();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
	 
	 
	 
 }
 

 
 static ArrayList<String> giveMeTextBetween(int count, String s, String before, String after) {
	ArrayList<String> result = new ArrayList<String>();
	
	int start = s.indexOf(before);

	start += before.length();
	int end = s.indexOf(after, start);
	
	for(int i = 0; i < count; ++i) {
		
		result.add(s.substring(start, end));
		start = s.indexOf(before, start);

		start += before.length();
		end = s.indexOf(after, start);
		//System.out.println(start);
		
	}
	
	return result;
} 


}







	
	

