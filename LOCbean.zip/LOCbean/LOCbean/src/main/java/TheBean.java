//********************************************************************************
//         File: TheBean.java
//       Author: Haris Bhatti, Adapted from work by Dr. Spiegel
//         Date: 12/15/2021
//     Computer: PCs and Suns
//      Purpose: To create a Bean for use with index.jsp and LibraryofCongressServlet 
//               
//
//********************************************************************************


 /**
 * @version 	1.00
 * @author 	Haris Bhatti + Various, based on work by Dr. Spiegel
 */


package BeanSauce;


/**
 *
 */

public class TheBean
{
	private String years;
	private String country;
	private String partof;

/**
 * @param val sets the years
 */

public void setyears(String val)
{
years = val;
}	


/**
 * @param val sets the country
 */

public void setcountry(String val)
{
country = val;
}	

/**
 * @param val sets the collection
 */

public void setpartof(String val)
{
partof = val;
}	

public String getyears()
{
	return years;
}

public String getcountry()
{
	return country;
}

public String getpartof()
{
	return partof;
}

public String getinfoheader()
{
	
	return("<h1>Films made in "+years+", in the country of "+country+" and part of the "+partof+" collection</h1>");
	
}

public String getqueryurl()
{


	return("https://www.loc.gov/film-and-videos/?fa=location%3A"+country+"%7Cpartof%3A"+partof+"%7Caccess-restricted%3Afalse&all=true&sb=title_s&dates="+years+"&st=list&c=150");
	
}



}