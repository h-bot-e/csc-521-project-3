Running the server

   - The server consists of two servlets along with a couple classes used by
   the servlets. The servlet runner must be running on port 8019 for the 
   software to work properly. The port can be changed by modifying the constants
   located in ClientActivities.java and then recompiling the class.

Running the standalone version

   - To run the standalone version of the Fred's Pharmacy software package
   double-click the file named "fred.jar" in the /standalone/client/ directory

Accessing the software online

   - To access the software online go to http://unixweb.kutztown.edu/~schi3008/cis521/servlets/Fred.html


Note: For the standalone client to work the server software must be running. (Mine is running)