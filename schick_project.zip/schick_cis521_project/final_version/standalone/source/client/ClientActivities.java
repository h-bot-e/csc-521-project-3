//********************************************************************************
//         File: ClientActivities.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To serve as a single access point for a client to communicate
//               with the server. This class includes methods for all of 
//               Fred's business activities.
//
//********************************************************************************

import java.util.*;
import java.lang.*;

public class ClientActivities
{
  // Server Message Tags
  public static final int SERVER = 1; // Server down

  // Login message tags
  public static final String LOGIN_NOK = "invalid"; // login failed
  public static final String LOGIN_SUS = "suspended"; // account suspended
  public static final String LOGIN_SERVER = "server error"; // Server down or error

  // Refill message tags
  public static final int PR_OK =  21;  // request succeeded
  public static final int PR_EXP = 22; // prescription expired
  public static final int PR_NON = 23; // no more refills
  public static final int PR_INV = 24; // invalid prescription number
  public static final int PR_DUP = 25; // already requested

  // List Prescription message tags
  public static final int LP     = 40; // request prescription list
  public static final int LP_NON = 41; // no recent prescriptions

  // Send message tags
  public static final int SEND_OK = 50; // message sent to fred successfully

  private static final String PR_SERVLET = "http://unixweb.kutztown.edu:8019/servlet/PRServlet";
  private static final String SMTP_SERVLET = "http://unixweb.kutztown.edu:8019/servlet/SMTPServlet";

  public ClientActivities()
   {
   }
  // Get all (refillable) prescriptions for a particular customer
  public static Vector getPrescriptions(Long customerNo)
   {
     ServletConnection conn = new ServletConnection(ClientActivities.PR_SERVLET);
     Vector data = new Vector();
     Prescription p;
     StringTokenizer pData;
     String parts = " ";
     int numPrescriptions = 0;

     if(!conn.openConnection())
      {
	// Return empty vector
	return data;
      }
     
     // Make the message
     String [] mess = {customerNo.toString()};
     PRMessage prescriptionMessage = new PRMessage(PRMessage.LP, mess);
    
     if(conn.writeObject(prescriptionMessage.toString()))
       {
         String str = new String();
         try
          {
            str = (String)conn.readObject();
          } 
         catch(Exception e)
          {
            // Return empty vector
            return data;
          }

         PRMessage reply = new PRMessage(str);
              
         if(reply.getTag() == PRMessage.LP_OK)
           {
             pData = new StringTokenizer(str, "|");
             numPrescriptions = ((pData.countTokens() - 1) / 8);

             // Move past tag
             if(pData.hasMoreTokens())
               { 
                 parts = pData.nextToken();
               }
             for(int i=0;i < numPrescriptions;i++)
               {
                 for(int j=0;j < 8;j++)
                   {
                     if(j > 0)
                      {
                        parts = parts + "|" + pData.nextToken();
                      }
                     else
                      {
                        parts = pData.nextToken();
                      }
                   } 
                 p = new Prescription(parts);
                 data.add(p);
               }
           }
       }
     return data;
   }
  // Get all open requests for a particular customer
  public static Vector getRefillRequests(Long customerNo)
   {
     ServletConnection conn = new ServletConnection(ClientActivities.PR_SERVLET);
     Vector data = new Vector();
     RefillRequest r;
     StringTokenizer rData;
     String parts = " ";
     int numRequests = 0;

     if(!conn.openConnection())
      {
        // Return empty vector
        return data;
      }
   
     // make the message
     String [] mess = {customerNo.toString(), PRMessage.CREATOR};
     PRMessage refReqMessage = new PRMessage(PRMessage.LR, mess);

     if(conn.writeObject(refReqMessage.toString()))
      {
        String str = new String();
         try
          {
            str = (String)conn.readObject();
          } 
         catch(Exception e)
          {
            // Return empty vector
            return data;
          }

         // decode reply
         PRMessage reply = new PRMessage(str);
              
         if(reply.getTag() == PRMessage.LR_OK)
          {
            rData = new StringTokenizer(str, "|");
            numRequests = ((rData.countTokens() - 1) / 6);

            // Move past tag
            if(rData.hasMoreTokens())
             { 
               parts = rData.nextToken();
             }
            for(int i=0;i < numRequests;i++)
             {
               for(int j=0;j < 6;j++)
                {
                  if(j > 0)
                   {
                     parts = parts + "|" + rData.nextToken();
                   }
                  else
                   {
                     parts = rData.nextToken();
                   }
                } 
               r = new RefillRequest(parts);
               data.add(r);
             }
          }
       }
     return data;     
   }
  // Request a refill - returns status constant
  public static synchronized int requestRefill(Long customerNo, String prescriptionNo, String store, String date, String time)
   {
     ServletConnection conn = new ServletConnection(ClientActivities.PR_SERVLET);
   
     if(!conn.openConnection())
      {
        return ClientActivities.SERVER;
      }
    
     // make the message
     String [] mess = { customerNo.toString(),
                        prescriptionNo,
                        store,
                        ClientActivities.parseDate(date, time),
                        PRMessage.CREATOR
                      };
     PRMessage refillMessage = new PRMessage(PRMessage.PR, mess);

     if(conn.writeObject(refillMessage.toString()))
      {
        String str = new String();
        try
         {
           str = (String)conn.readObject();
         } 
        catch(Exception e)
         {
           return ClientActivities.SERVER;
         }
 
        // decode reply
        PRMessage reply = new PRMessage(str);      

        // Map constants
        switch(reply.getTag())
         {
           case PRMessage.PR_OK: return ClientActivities.PR_OK;
           case PRMessage.PR_EXP: return ClientActivities.PR_EXP;
           case PRMessage.PR_NON: return ClientActivities.PR_NON;
           case PRMessage.PR_INV: return ClientActivities.PR_INV;
           case PRMessage.PR_DUP: return ClientActivities.PR_DUP;
           default: return ClientActivities.SERVER;
         }
      }
     return ClientActivities.SERVER;
   }
  // Update a refill request - returns status constant
  public static synchronized int updateRequest(Long customerNo, String prescriptionNo, String store, String date, String time)
   {
     ServletConnection conn = new ServletConnection(ClientActivities.PR_SERVLET);
   
     if(!conn.openConnection())
      {
        return ClientActivities.SERVER;
      }
    
     // make the message
     String [] mess = { customerNo.toString(),
                        prescriptionNo,
                        store,
                        ClientActivities.parseDate(date, time),
                        PRMessage.CREATOR
                      };
     PRMessage refillMessage = new PRMessage(PRMessage.PR_UPDT, mess);

     if(conn.writeObject(refillMessage.toString()))
      {
        String str = new String();
        try
         {
           str = (String)conn.readObject();
         } 
        catch(Exception e)
         {
           return ClientActivities.SERVER;
         }
 
        // decode reply
        PRMessage reply = new PRMessage(str);      

        // Map constants
        switch(reply.getTag())
         {
           case PRMessage.PR_OK: return ClientActivities.PR_OK;
           default: return ClientActivities.SERVER;
         }
      }
     return ClientActivities.SERVER;
   }
  // Login
  public static User verifyLogin(String user, String pass)
   {
     ServletConnection conn = new ServletConnection(ClientActivities.PR_SERVLET);
     StringTokenizer parts;
     String userId;
     String fName;
     String lName;
     String uType;

     if(!conn.openConnection())
      {
	return new User(ClientActivities.LOGIN_SERVER, " ", " ");
      }
	
     // make the message
     String [] mess = {user, pass};
     PRMessage loginMessage = new PRMessage(PRMessage.LOGIN, mess);

     if(conn.writeObject(loginMessage.toString()))
      {
        String str = new String();
        try
         {
           str = (String)conn.readObject();
         } 
        catch(Exception e)
         {
	   return new User(ClientActivities.LOGIN_SERVER, " ", " ");
         }

        // decode reply 
        PRMessage reply = new PRMessage(str);
       
        switch(reply.getTag())
         {
           case PRMessage.LOGIN_OK:
             parts = new StringTokenizer(str, "|");
             try
              {
                userId = parts.nextToken();  // skip past tag
                userId = parts.nextToken();
                lName = parts.nextToken();
                fName = parts.nextToken();
                uType = parts.nextToken();
              }
             catch(Exception e)
              {
                return new User(ClientActivities.LOGIN_SERVER, " ", " ");
              }
             return new User(userId, fName + " " + lName, uType);
           case PRMessage.LOGIN_NOK: 
             return new User(ClientActivities.LOGIN_NOK, " ", " ");
           case PRMessage.LOGIN_SUS: 
             return new User(ClientActivities.LOGIN_SUS, " ", " ");
           default: 
             return new User(ClientActivities.LOGIN_SERVER, " ", " ");
         }
      }
     return new User(ClientActivities.LOGIN_SERVER, " ", " ");
   }
  // Send a message to Fred via smtp
  public static int sendMessage(String subject, String message)
   { 
     ServletConnection conn = new ServletConnection(ClientActivities.SMTP_SERVLET);
   
     if(!conn.openConnection())
      {
        return ClientActivities.SERVER;
      }
    
     // make the message
     String mess = " |Fred_Online_Customer| |" + subject + "|" + message + "| ";

     if(conn.writeObject(mess))
      {
        String str = new String();
        try
         {
           str = (String)conn.readObject();
         } 
        catch(Exception e)
         {
           return ClientActivities.SERVER;
         }
 
        // decode reply
        PRMessage reply = new PRMessage(str);      

        // Map constants
        switch(reply.getTag())
         {
           case SMTPMessage.SEND_OK: return ClientActivities.SEND_OK;
           default: return ClientActivities.SERVER;
         }
      }
     return ClientActivities.SERVER;
   }
     
  //*****************************************************
  // ParseDate - puts a date into Oracle compatible format
  //*****************************************************
  // the following is used later for Oracle Date
  // it is compatible with Oracle's to_date function
  // as to_date( String, 'MONTH DD YYYY HH:SS AM');
  private static String parseDate(String d, String t)
   {
      String day = new String("");
      String date = new String("");
      String year = new String("");
      String pickupDate = new String("");
      StringTokenizer strings = new StringTokenizer(d, ",");

      day = strings.nextToken();
      date = strings.nextToken();
      year = strings.nextToken();

      date = date.trim();
      t = t.trim();

      pickupDate = date + year + " " + t;
   
      return pickupDate;
   }
}
