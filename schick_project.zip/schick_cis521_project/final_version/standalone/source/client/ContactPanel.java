//********************************************************************************
//         File: ContactPanel.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To allow a user to send a message using SMTPServlet.
//
//********************************************************************************

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ContactPanel extends JPanel implements ActionListener
{
  private JLabel titleLabel;
  private JLabel nameLabel;
  private JTextField nameField;
  private JLabel emailLabel;
  private JTextField emailField;
  private JLabel subjectLabel;
  private JTextField subjectField;
  private JScrollPane textPane;
  private JTextArea textArea;
  private JButton sendButton;
  private JButton clearButton;
  private JLabel statusLabel;
  private JPanel infoPanel;
  private JPanel buttonPanel;
  private JPanel bp1;
  private JPanel bp2;
  private long custNo;
  private String phoneNo = "800-999-9999";
  private JLabel phoneLabel;

  public ContactPanel(long customerNo)
   {
     super();
     setLayout(new BorderLayout());
     setBackground(Color.white);
     setCustNo(customerNo); 

     titleLabel = new JLabel("Contact Us");
     nameLabel = new JLabel("Name");
     nameField = new JTextField(30);
     emailLabel = new JLabel("Email Address");
     emailField = new JTextField(30);
     subjectLabel = new JLabel("Subject");
     subjectField = new JTextField(40);
     textArea = new JTextArea(30, 40);
     textPane = new JScrollPane(textArea);
     sendButton = new JButton("Send");
     clearButton = new JButton("Clear");
     statusLabel = new JLabel("Fill out the contact form and click send to contact Fred");
     statusLabel.setForeground(Color.black);
     phoneLabel = new JLabel("Phone: " + phoneNo);
     infoPanel = new JPanel();
     buttonPanel = new JPanel();
     bp1 = new JPanel();
     bp2 = new JPanel();

     // Set up panels and add components
     infoPanel.setLayout(new GridLayout(4, 2, 5, 5));
     infoPanel.setBackground(new Color(255, 213, 213));
     infoPanel.add(titleLabel);
     infoPanel.add(phoneLabel);
     infoPanel.add(nameLabel);
     infoPanel.add(nameField);
     infoPanel.add(emailLabel);
     infoPanel.add(emailField);
     infoPanel.add(subjectLabel);
     infoPanel.add(subjectField);

     buttonPanel.setLayout(new BorderLayout());
     buttonPanel.setBackground(new Color(255, 213, 213));
     bp1.setBackground(new Color(255, 213, 213));
     bp2.setBackground(new Color(255, 213, 213));
     bp1.add(sendButton);
     bp1.add(clearButton);
     bp2.add(statusLabel);
     buttonPanel.add("North", bp1);
     buttonPanel.add("South", bp2);

     add("North", infoPanel);
     add("Center", textPane);
     add("South", buttonPanel);

     // Register listeners
     sendButton.addActionListener(this);
     clearButton.addActionListener(this);          
   }
  public void actionPerformed(ActionEvent ae)
   {
     Object source = ae.getSource();

     if(source == sendButton)
      {
        if(nameField.getText().equals(""))
         {
           statusLabel.setForeground(Color.red);
           statusLabel.setText("Please provide a name");
           return;
         }
        if(subjectField.getText().equals(""))
         {
           statusLabel.setForeground(Color.red);
           statusLabel.setText("Please provide a subject");
           return;
         }
        if(textArea.getText().equals(""))
         {
           statusLabel.setForeground(Color.red);
           statusLabel.setText("Include your question or comment in the body of this message");
           return;
         }

        // Disable buttons
        sendButton.setEnabled(false);
        clearButton.setEnabled(false);

        // Create message
        String message = "Customer No.: " + (new Long(getCustNo())).toString() + "\n"
            + "Customer Name: " + nameField.getText() + "\n"
            + "Customer Email Address: " + emailField.getText() + "\n\n"
            + "Message Body: \n"
            + textArea.getText() + "\n\n";
    
        // Send message
        int check = ClientActivities.sendMessage(subjectField.getText(), message);

        if(check != ClientActivities.SEND_OK)
         {
           statusLabel.setForeground(Color.red);
           statusLabel.setText("An error occurred while sending your message. Please try again later.");
           sendButton.setEnabled(true);
	   clearButton.setEnabled(true);
           return;
         }

        // Message sent successfully
        clearForm();
        statusLabel.setForeground(Color.blue);
        statusLabel.setText("Message sent");
        sendButton.setEnabled(true);
        clearButton.setEnabled(true);
      }
     else if(source == clearButton)
      {
        clearForm();
      }
   }
  private void clearForm()
   {
     nameField.setText("");
     emailField.setText(""); 
     subjectField.setText("");
     textArea.setText("");
     statusLabel.setText("Fill out the contact form and click send to contact Fred");
     statusLabel.setForeground(Color.black);
   }
  private void setCustNo(long no)
   {
     custNo = no;
   }
  private long getCustNo()
   {
     return custNo;
   }
}
