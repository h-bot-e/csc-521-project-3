//********************************************************************************
//         File: CustomerInterface.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To provide a GUI for customers who have an online account with
//               Fred's Pharmacy.
//
//********************************************************************************

import javax.swing.*;
import java.awt.*;


public class CustomerInterface extends JPanel
{
  private CustomerPanel cp;
  private JPanel welcomePanel;
  private JLabel welcomeLabel;
  Font appFont = new Font("Serif", Font.PLAIN, 12);
  FontMetrics metrics = getFontMetrics(appFont);

  public CustomerInterface(User usr)
    {
      super();
      setFont(appFont);
      setForeground(Color.white);
      setBackground(Color.white);
      setLayout(new BorderLayout());
      cp = new CustomerPanel(Long.parseLong(usr.getUserId(), 10));
      welcomePanel = new JPanel();
      welcomeLabel = new JLabel("Welcome " + usr.getUserName());
      welcomePanel.setBackground(Color.white);
  
      welcomePanel.add(welcomeLabel);
      add("North", welcomePanel);
      add("Center", cp);
    }
}