//********************************************************************************
//         File: FredClient.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To allow a user to perform the same operations available in 
//               Fred's online software in a standalone environment.
//
//********************************************************************************

import javax.swing.*;
import java.awt.*;

public class FredClient extends JFrame implements LoginListener
{
  private Font appFont = new Font("Serif", Font.PLAIN, 12);
  private FontMetrics metrics = getFontMetrics(appFont);
  private LoginPanel lp;
  private JPanel loginPane;
  private JPanel msgPane;
  private JLabel msg;
              

  public FredClient()
    {
      super("Fred's Pharmacy Client");
      setSize(new Dimension(400, 150));
      setResizable(false);
      setFont(appFont);
      setForeground(Color.white);
      setBackground(Color.white);
      Container content = getContentPane();
      content.setLayout(new BorderLayout());
       
      lp = new LoginPanel();

      loginPane = new JPanel();
      loginPane.setBackground(Color.white);
      loginPane.add(lp);

      msgPane = new JPanel();
      msgPane.setBackground(Color.white);
      msg = new JLabel("");
      msgPane.add(msg);
      
      content.add("Center", loginPane);
      lp.addLoginListener(this);
      setVisible(true);
    }
  public void loginAttempted(LoginEvent le)
    {
      Object source = le.getSource();

      if(source == lp)
        {
          Container content = getContentPane();
          User usr;
          if(le.getLogin().getStatus() == Login.GRANTED)
            {
              usr = lp.getUser();
              content.removeAll();
              
              if(usr.getUserType().equals("c") || usr.getUserType().equals("C"))
                {
                  setVisible(false);
                  setSize(new Dimension(800, 850));
                  content.doLayout();  // may not be required
                  content.add("Center", new CustomerInterface(lp.getUser()));
                  setVisible(true);
                }
              else if(usr.getUserType().equals("d") || usr.getUserType().equals("D"))
                {
                  msg.setText("Access for doctors is not supported at this time.");
                  content.add("Center", msgPane);
                }
              else if(usr.getUserType().equals("e") || usr.getUserType().equals("E"))
                {
                  msg.setText("Access for employees is not supported at this time.");
                  content.add("Center", msgPane);
                }
              else if(usr.getUserType().equals("s") || usr.getUserType().equals("S"))
                {
                  msg.setText("Your account is suspended. Please call your local Fred's Pharmacy.");
                  content.add("Center", msgPane);
                }
              else
                {
                  msg.setText("There is a problem with your account. Please contant your local "
                              + "Fred's Pharmacy.");
                  content.add("Center", msgPane);
                }
              
              content.doLayout();
            }
          return;
        }
    }
  public static void main(String[] args)
    {
      FredClient fred = new FredClient();
    }
}
