//********************************************************************************
//         File: Login.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To provide a simple wrapper around data associated with a
//               login attempt.
//
//********************************************************************************

public class Login
{
  public static final int GRANTED = 1;
  public static final int DENIED  = 2;

  private int status;

  public Login(int loginStatus)
   {
     setStatus(loginStatus);
   }
  private void setStatus(int s)
   {
     status = s;
   }
  public int getStatus()
   {
     return status;
   } 
}