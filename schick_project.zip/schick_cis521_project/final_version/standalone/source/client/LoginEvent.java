//********************************************************************************
//         File: LoginEvent.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: This class represents an event created when somebody tries to 
//               login to a secure resource.
//
//********************************************************************************

import java.util.EventObject;

public class LoginEvent extends EventObject
{
  private Login login;

  public LoginEvent(Object source, Login l)
   {
     super(source);
     login = l;
   }
  // Return the Login
  public Login getLogin()
   {
     return login;
   }
}