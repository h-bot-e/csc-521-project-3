//********************************************************************************
//         File: LoginListener.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: This interface is implemented to allow an object to be notified 
//               when a login event occurs.
//
//********************************************************************************

public interface LoginListener
{
  public void loginAttempted(LoginEvent le);
}