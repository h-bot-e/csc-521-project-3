//********************************************************************************
//         File: LoginPanel.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To prompt the user for a username and password before entering 
//               a secure area. This panel generates LoginEvents every time a 
//               user enters a username, password, and presses the login button.
//
//********************************************************************************

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class LoginPanel extends JPanel 
             implements ActionListener, KeyListener
{
  private List listeners;
  private JTextField uname;
  private JPasswordField pass;
  private JLabel unameLabel;
  private JLabel passLabel;
  private JButton login;
  private JPanel loginPanel;
  private JPanel unamePanel;
  private JPanel passPanel;
  private JPanel statusPanel;
  private JLabel status;
  private User prUser;
  private Boolean loginStatusLock;
  private boolean loginStatus;

  public LoginPanel()
   {
     super();
     setBackground(Color.white);
     setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
     listeners = new ArrayList();

     unamePanel = new JPanel();
     passPanel = new JPanel();
     loginPanel = new JPanel();
     statusPanel = new JPanel();
     unamePanel.setLayout(new BoxLayout(unamePanel, BoxLayout.X_AXIS));
     unamePanel.setBackground(Color.white);
     passPanel.setLayout(new BoxLayout(passPanel, BoxLayout.X_AXIS));
     passPanel.setBackground(Color.white);
     loginPanel.setLayout(new BoxLayout(loginPanel, BoxLayout.X_AXIS));
     loginPanel.setBackground(Color.white);
     statusPanel.setLayout(new BoxLayout(statusPanel, BoxLayout.X_AXIS));
     statusPanel.setBackground(Color.white);
     
     uname = new JTextField(15);
     pass = new JPasswordField(15);
     unameLabel = new JLabel("Username");
     passLabel = new JLabel("Password");
     login = new JButton("Login");
     status = new JLabel(" ");
     setUser(new User("unknown", " ", " "));
     loginStatusLock = Boolean.valueOf(false);
     setLoginStatus(false);
     
     unamePanel.add(Box.createHorizontalGlue());
     unamePanel.add(unameLabel);
     unamePanel.add(Box.createHorizontalStrut(10));
     unamePanel.add(uname);
     unamePanel.add(Box.createHorizontalGlue());

     passPanel.add(Box.createHorizontalGlue());
     passPanel.add(passLabel);
     passPanel.add(Box.createHorizontalStrut(11)); // one more than uname for symmetry
     passPanel.add(pass);
     passPanel.add(Box.createHorizontalGlue());

     statusPanel.add(status);

     loginPanel.add(login);

     add(Box.createHorizontalGlue());
     add(Box.createVerticalGlue());
     add(statusPanel);
     add(Box.createVerticalStrut(5));
     add(unamePanel);
     add(passPanel);
     add(Box.createVerticalStrut(5));
     add(loginPanel);
     add(Box.createVerticalGlue()); 
     add(Box.createHorizontalGlue());

     // Register listeners
     login.addActionListener(this);
     login.addKeyListener(this);
     pass.addKeyListener(this);
     uname.addKeyListener(this);
   }
  public synchronized void actionPerformed(ActionEvent ae)
   {
     Object source = ae.getSource();

     if(source == login)
       {
         login.setEnabled(false);
         User usr;
         String userId;
         String password = new String(pass.getPassword());
         status.setText(" ");
         if(uname.getText().length() <= 0 || password.length() <= 0)
           {
             status.setText("Blank username or password.");
             login.setEnabled(true);
             return;
           }
         usr = ClientActivities.verifyLogin(uname.getText(), password);
         userId = usr.getUserId();

         // Check to see if login was successful
         if(userId.equals(ClientActivities.LOGIN_NOK))
           {
             status.setText("Invalid username or password.");
             setLoginStatus(false);
             uname.setText("");
             pass.setText("");
           }
         else if(userId.equals(ClientActivities.LOGIN_SUS))
           {
             status.setText("Account suspended.");
             setLoginStatus(false);
             uname.setText("");
             pass.setText("");
           }
         else if(userId.equals(ClientActivities.LOGIN_SERVER))
           {
             status.setText("Error communicating with server. Please try again later.");
             setLoginStatus(false);
             uname.setText("");
             pass.setText("");
           }
         else // login successful
           { 
             status.setText("Login success.");
             setUser(usr);
             setLoginStatus(true);
             uname.setText("");
             pass.setText("");
           }

         login.setEnabled(true);
         return;
       }
   }
  public void keyReleased(KeyEvent event) 
   {
   }
  public void keyPressed(KeyEvent event) 
   {
     ActionEvent ae = new ActionEvent(event.getSource(), 
                            ActionEvent.ACTION_PERFORMED, 
                            login.getActionCommand());

     if(event.getKeyCode() == KeyEvent.VK_TAB)
       {
         if(event.getSource() == uname)
           {
             pass.requestFocus();
           }
         else if(event.getSource() == pass)
           {
             login.requestFocus();
           }
         else if(event.getSource() == login)
           {
             uname.requestFocus();
           }
         else
           {
             event.getComponent().transferFocus();
           }
       }
     else if(event.getKeyCode() == KeyEvent.VK_ENTER)
       {
         login.dispatchEvent(ae);
       }
   }
  public void keyTyped(KeyEvent event) 
   {
   }
  // Adds a listener to the list
  public void addLoginListener(LoginListener l)
   {
     synchronized(listeners)
       {
         listeners.add(l);
       }
   }
  // Allows a registered listener to remove itself from the 
  // listener list
  public void removeLoginListener(LoginListener l)
   {
     synchronized(listeners)
       {
         listeners.remove(l);
       }
   }
  private void setLoginStatus(boolean b)
   {
     synchronized(loginStatusLock)
       {
         loginStatus = b;
         fireLoginEvent();
       }
   }
  public boolean getLoginStatus()
   {
     return loginStatus;
   }
  // Notifies each listener registered with this LoginPanel that
  // a login was attempted
  private void fireLoginEvent()
   {
     Login login = new Login(Login.DENIED);

     if(getLoginStatus())
       {
         login = new Login(Login.GRANTED);  
       }  
     LoginEvent le = new LoginEvent(this, login);
     synchronized(listeners)
       {
         Iterator itrListeners = listeners.iterator();
     
         while(itrListeners.hasNext())
           {
             ((LoginListener)itrListeners.next()).loginAttempted(le);
           }
       }  
   }
  private void setUser(User u)
   {
     prUser = u;
   }
  public User getUser()
   {
     return prUser;
   }
}