//********************************************************************************
//         File: PRTableModel.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: This abstract class provides a base class for all table models 
//               used to display data associated with Fred's Pharmacy.
//
//********************************************************************************

import java.util.Vector;
import javax.swing.*;
import javax.swing.table.*;


public abstract class PRTableModel extends AbstractTableModel
{
  private Vector data;       // vector to hold the data objects
  private String headers[];  // array of headings for each column
  private Class colTypes[];  // array of types of the data in each column
  private int columnCount;   // number of columns
   
  public PRTableModel(String[] colHeaders, Class[] columnTypes, int colCount)
   {
     data = new Vector();       
     headers = colHeaders;      
     colTypes = columnTypes;    
     setColumnCount(colCount);  // set the number of columns
   }

  /********* Start implementation of TableModel Interface ***********/

  public int getRowCount()
   {
     return data.size();
   }
  public int getColumnCount()
   {
     return columnCount;
   }
  public String getColumnName(int c)
   {
     return headers[c];
   }
  public Class getColumnClass(int c)
   {
     return colTypes[c];
   }
  public Object getValueAt(int row, int col)
   {
     return ((PRTableObject)data.elementAt(row)).getProperty(col);
   }
  public void setValueAt(Object aValue, int row, int col)
   {
     ((PRTableObject)data.elementAt(row)).setProperty(col, (String)aValue);
   }
  public boolean isCellEditable(int row, int col)
   {
     return ((PRTableObject)data.elementAt(row)).isPropertyEditable(col);
   }
  
  /********* End implementation of TableModel Interface ***********/

  public abstract void getData(Long customerNo);
  
  // Clear the table
  protected void clearTable()
   {
     data.clear();
   }
  protected void addObject(Object obj)
   {
     data.add(obj);
   }
  protected Object getObject(int row)
   {
     return data.elementAt(row); 
   }
  protected void setColumnCount(int count)
   {
     columnCount = count;
   }
  
}