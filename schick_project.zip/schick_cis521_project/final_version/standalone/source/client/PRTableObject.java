//********************************************************************************
//         File: PRTableObject.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: This interface includes the methods that an object needs to 
//               implement in order for its data to be easily extracted for
//               used in a JTable. 
//
//********************************************************************************

public interface PRTableObject
{
  // Get the header for each property
  public String[] getHeaders();
   
  // Get the type of each property
  public Class[] getPropertyTypes();
   
  // Get the number of properties
  public int getPropertyCount();
  
  // Set a property by number
  public void setProperty(int num, String value);

  // Get a property by number
  public String getProperty(int num);

  // Check to see if a property is editable by number
  public boolean isPropertyEditable(int num);
}