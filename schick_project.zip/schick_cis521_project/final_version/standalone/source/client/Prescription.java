//********************************************************************************
//         File: Prescription.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To represent a prescription in a JTable. This class provides 
//               methods which simplify the extraction of prescription related
//               data for placement in a JTable environment.
//
//********************************************************************************

import java.util.*;

public class Prescription implements PRTableObject
{
  // Property numbers
  private static final int PROP_COUNT = 8;
  public static final int PRESCRIPTION_NO = 0;
  public static final int DRUG_NAME = 1;
  public static final int DOCTOR = 2;
  public static final int INSTRUCTIONS = 3;
  public static final int PRESCRIPTION_DATE = 4;
  public static final int QUANTITY = 5;
  public static final int REFILLS_REMAINING = 6;
  public static final int EXP_DATE = 7;

  // Attributes of a prescription
  private String prescriptionNo;
  private String drug;
  private String doctor;
  private String instructions;
  private String date;
  private String quantity;
  private String refillsLeft;
  private String expDate;

  // Booleans for determining if a property is editable or not
  private boolean prescriptionNoEditable;
  private boolean drugEditable;
  private boolean doctorEditable;
  private boolean instructionsEditable;
  private boolean dateEditable;
  private boolean quantityEditable;
  private boolean refillsLeftEditable;
  private boolean expDateEditable;
 
  // Headings for properties
  private static String[] propNames = new String[]{"Prescription No.", "Drug", 
                                    "Doctor", "Instructions", "Prescription Date",
                                    "Quantity", "Refills Left", "Expiration Date"};

  // Types for properties
  private static Class[] propTypes = new Class[]{String.class, String.class, 
                                     String.class, String.class, String.class,
                                     String.class, String.class, String.class};
  

  public Prescription()
   {
     for(int i=0;i < PROP_COUNT;i++)
       {
         setProperty(i, new String(""));
       }
     setPrescriptionNoEditable(false);
     setDrugEditable(false);
     setDoctorEditable(false);
     setInstructionsEditable(false);
     setDateEditable(false);
     setQuantityEditable(false);
     setRefillsLeftEditable(false);
     setExpDateEditable(false);
   }
  public Prescription(String data)
   {
     StringTokenizer p = new StringTokenizer(data, "|");

     for(int i=0;i < PROP_COUNT;i++)
       {
         setProperty(i, new String(""));
       }

     for(int i=0;p.hasMoreElements() && i < PROP_COUNT;i++)
       {
         setProperty(i, p.nextToken());
       }
     setPrescriptionNoEditable(false);
     setDrugEditable(false);
     setDoctorEditable(false);
     setInstructionsEditable(false);
     setDateEditable(false);
     setQuantityEditable(false);
     setRefillsLeftEditable(false);
     setExpDateEditable(false);
   }
  public String[] getHeaders()
   {
     return propNames;
   }
  public Class[] getPropertyTypes()
   {
     return propTypes;
   }
  public int getPropertyCount()
   {
     return Prescription.PROP_COUNT;
   }
  // Set a property using its number
  public void setProperty(int num, String value)
   {
     switch(num)
       {
         case PRESCRIPTION_NO:    setPrescriptionNo(value);
                                  break;
         case DRUG_NAME:          setDrug(value);
                                  break;
         case DOCTOR:             setDoctor(value);
                                  break;
         case INSTRUCTIONS:       setInstructions(value);
                                  break;
         case PRESCRIPTION_DATE:  setDate(value);
                                  break;
         case QUANTITY:           setQuantity(value);
                                  break;
         case REFILLS_REMAINING:  setRefillsLeft(value);
                                  break;
         case EXP_DATE:           setExpDate(value);
                                  break;
         default:                 System.err.println("Unknown Prescription property: " + num);
                                  break;
       }
   }
  // Get a property using its number
  public String getProperty(int num)
   {
     switch(num)
       {
         case PRESCRIPTION_NO:    return getPrescriptionNo();
                                 
         case DRUG_NAME:          return getDrug();
                                  
         case DOCTOR:             return getDoctor();
                                  
         case INSTRUCTIONS:       return getInstructions();
                                  
         case PRESCRIPTION_DATE:  return getDate();
                                  
         case QUANTITY:           return getQuantity();
                                  
         case REFILLS_REMAINING:  return getRefillsLeft();
                                  
         case EXP_DATE:           return getExpDate();
                                  
         default:                 System.err.println("Unknown Prescription property: " + num);
                                  return new String("");
                                  
       }
   }
  // Check to see whether a property is editable in a table
  public boolean isPropertyEditable(int num)
   {
     switch(num)
       {
         case PRESCRIPTION_NO:    return isPrescriptionNoEditable();
                                 
         case DRUG_NAME:          return isDrugEditable();
                                  
         case DOCTOR:             return isDoctorEditable();
                                  
         case INSTRUCTIONS:       return isInstructionsEditable();
                                  
         case PRESCRIPTION_DATE:  return isDateEditable();
                                  
         case QUANTITY:           return isQuantityEditable();
                                  
         case REFILLS_REMAINING:  return isRefillsLeftEditable();
                                  
         case EXP_DATE:           return isExpDateEditable();
                                  
         default:                 return false;
                                  
       }
   }
  public boolean isPrescriptionNoEditable()
   {
     return prescriptionNoEditable;
   }
  public void setPrescriptionNoEditable(boolean b)
   {
     prescriptionNoEditable = b;
   }
  public boolean isDrugEditable()
   {
     return drugEditable;
   }
  public void setDrugEditable(boolean b)
   {
     drugEditable = b;
   }
  public boolean isDoctorEditable()
   {
     return doctorEditable;
   }
  public void setDoctorEditable(boolean b)
   {
     doctorEditable = b;
   }
  public boolean isInstructionsEditable()
   {
     return instructionsEditable;
   }
  public void setInstructionsEditable(boolean b)
   {
     instructionsEditable = b;
   }
  public boolean isDateEditable()
   {
     return dateEditable;
   }
  public void setDateEditable(boolean b)
   {
     dateEditable = b;
   }
  public boolean isQuantityEditable()
   {
     return quantityEditable;
   }
  public void setQuantityEditable(boolean b)
   {
     quantityEditable = b;
   }
  public boolean isRefillsLeftEditable()
   {
     return refillsLeftEditable;
   }
  public void setRefillsLeftEditable(boolean b)
   {
     refillsLeftEditable = b;
   }
  public boolean isExpDateEditable()
   {
     return expDateEditable;
   }
  public void setExpDateEditable(boolean b)
   {
     expDateEditable = b;
   }
  public void setPrescriptionNo(String num)
   {
     prescriptionNo = num;
   }
  public String getPrescriptionNo()
   {
     return prescriptionNo;
   } 
  public void setDrug(String d)
   {
     drug = d;
   }
  public String getDrug()
   {
     return drug;
   } 
  public void setDoctor(String d)
   {
     doctor = d;
   }
  public String getDoctor()
   {
     return doctor;
   } 
  public void setInstructions(String i)
   {
     instructions = i;
   }
  public String getInstructions()
   {
     return instructions;
   } 
  public void setDate(String dt)
   {
     date = dt;
   }
  public String getDate()
   {
     return date;
   } 
  public void setQuantity(String q)
   {
     quantity = q;
   }
  public String getQuantity()
   {
     return quantity;
   } 
  public void setRefillsLeft(String rl)
   {
     refillsLeft = rl;
   }
  public String getRefillsLeft()
   {
     return refillsLeft;
   } 
  public void setExpDate(String exp)
   {
     expDate = exp;
   }
  public String getExpDate()
   {
     return expDate;
   } 
  public String toString()
   {
     return prescriptionNo + "|" + drug + "|" + doctor + "|" + instructions + "|" 
            + date + "|" + quantity + "|" + refillsLeft + "|" + expDate;
   }
}