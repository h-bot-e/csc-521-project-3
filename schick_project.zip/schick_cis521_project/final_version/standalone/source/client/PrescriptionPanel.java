//********************************************************************************
//         File: PrescriptionPanel.java
//       Author: Joe Schick
//         Date: 12/03/03
//     Computer: PCs and Suns
//      Purpose: To provide a GUI which allows a customer of Fred's Pharmacy to 
//               view their refillable prescription, view their current refill
//               requests, make a new request, and update a request.
//
//********************************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.lang.*;
import java.util.*;
import java.util.StringTokenizer;
import java.text.*;


public class PrescriptionPanel extends JPanel 
          implements ActionListener, ItemListener, KeyListener
{
  private static final String DATE_FORMAT = "EEE MMM dd HH:mm:ss zzz yyyy";

  // Prescription and refill request tables
  private long custNo;
  private JTable prescriptionTable;
  private JTable refillRequestTable;
  private PrescriptionTableModel pModel;
  private RefillRequestTableModel rModel;
  private JScrollPane refillRequestPane;  // for requested refills table
  private JScrollPane prescriptionPane;   // for prescription table
  private JPanel prescriptionPanel;
  private JPanel refillRequestPanel;
  private JPanel refillPanel;
  private JButton refreshPrescription;
  private JButton refreshRefillRequest;
  private JPanel refreshPrescriptionPanel;
  private JPanel refreshRefillRequestPanel;
  private JLabel prescriptionTableLabel;
  private JLabel refillRequestTableLabel;
  
  // Refill request
  private JTextField prescriptionID;
  private JComboBox store;  
  private JComboBox date;
  private JComboBox time;
  private JLabel status;
  private JButton submitButton;
  private JButton clearButton;
  private JLabel prescriptionLabel;
  private JLabel storeLabel;
  private JLabel dateLabel;
  private JLabel timeLabel;
  private JLabel statusLabel;
  private JLabel requestRefillLabel;
  private JPanel p1;
  private JPanel p2;
  private boolean isUpdate;

  // the following are used in later development
  private String refillData;
  private String pickupDate;
  private boolean connected = false;

  private static final String [] STORES =
   { "Select a store for pick-up", "Fogelsville", "Breinigsville"};

  private static final String [] MONTHS = 
   { "January", "February", "March", "April", "May", "June",
     "July", "August", "September", "October", "November", "December"};

  private static final String [] DAYS =
   { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday",
     "Friday", "Saturday"};

  public PrescriptionPanel(long customerNo)
    {
      super();
      setLayout(new GridLayout(3, 1, 10, 0));
      setBackground(Color.white);
      setCustNo(customerNo); 

      prescriptionPanel = new JPanel();
      prescriptionPanel.setLayout(new BorderLayout());
      prescriptionPanel.setBackground(new Color(202, 228, 255));
      refillRequestPanel = new JPanel();
      refillRequestPanel.setLayout(new BorderLayout());
      refillRequestPanel.setBackground(new Color(202, 228, 255));
      refillPanel = new JPanel();
      refillPanel.setLayout(new BorderLayout());
      refillPanel.setBackground(new Color(202, 228, 255));
      refreshPrescriptionPanel = new JPanel();
      refreshPrescriptionPanel.setBackground(new Color(202, 228, 255));
      refreshRefillRequestPanel = new JPanel();
      refreshRefillRequestPanel.setBackground(new Color(202, 228, 255));
      refreshPrescription = new JButton("Refresh");
      refreshRefillRequest = new JButton("Refresh");
      prescriptionTableLabel = new JLabel("Prescriptions - double-click a prescription to request a refill for it");
      refillRequestTableLabel = new JLabel("Requested Refills - double-click a request to edit it; only requests with status = R can be edited");
    
      // Set up prescription table
      pModel = new PrescriptionTableModel();
      prescriptionTable = new JTable(pModel);
      prescriptionTable.setBackground(Color.white);
      prescriptionPane = new JScrollPane(prescriptionTable);
      pModel.getData(new Long(customerNo));

      // Set up refill table
      rModel = new RefillRequestTableModel();
      refillRequestTable = new JTable(rModel);
      refillRequestTable.setBackground(Color.white);
      refillRequestPane = new JScrollPane(refillRequestTable);
      rModel.getData(new Long(customerNo));

      refreshPrescription.addActionListener(this);
      refreshRefillRequest.addActionListener(this);

      refreshPrescriptionPanel.add(refreshPrescription);
      prescriptionPanel.add("North", prescriptionTableLabel);
      prescriptionPanel.add("Center", prescriptionPane);
      prescriptionPanel.add("South", refreshPrescriptionPanel);

      refreshRefillRequestPanel.add(refreshRefillRequest);
      refillRequestPanel.add("North", refillRequestTableLabel);
      refillRequestPanel.add("Center", refillRequestPane);
      refillRequestPanel.add("South", refreshRefillRequestPanel);
 
      // Listen for double clicks on prescriptionTable      
      prescriptionTable.addMouseListener(new MouseAdapter() {
	      public void mouseClicked(MouseEvent me)
	      {
	        if(me.getClickCount() >= 2)
		 {
		   refillPrescription(prescriptionTable.getSelectedRow(), pModel);
		 }
	      }} );

      // Listen for double clicks on requestRefillTable
      refillRequestTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent me)
             {
               if(me.getClickCount() >= 2)
                {
                  editRequestRow(refillRequestTable.getSelectedRow(), rModel);
                }
             }} );

      // Set up refill panel
      p1 = new JPanel(new GridLayout(6,2,5,5));
      p1.setBackground(new Color(202, 228, 255));
      p2 = new JPanel(new FlowLayout());
      p2.setBackground(new Color(202, 228, 255));
      prescriptionID = new JTextField(30);
      prescriptionID.setEnabled(false);
      store = new JComboBox();  
      date = new JComboBox();
      time = new JComboBox();
      status = new JLabel("Fill Form and press Submit Request");
      submitButton = new JButton("Submit Request");
      clearButton = new JButton("Clear");
      prescriptionLabel = new JLabel("Prescription Number");
      storeLabel  = new JLabel("Pick-Up Store");
      dateLabel   = new JLabel("Pick-Up Date");
      timeLabel   = new JLabel("Time");
      statusLabel = new JLabel("Status ");
      requestRefillLabel = new JLabel("Request a Refill");

      refillPanel.add(p1, "Center");
      refillPanel.add(p2, "South");
      refillPanel.add(requestRefillLabel, "North");

      p1.add(prescriptionLabel);
      p1.add(prescriptionID);
      prescriptionID.setBackground(Color.white);
      prescriptionID.requestFocus();

      p1.add(storeLabel);
      p1.add(store);
      for(int i=0; i < STORES.length; i++)
         store.addItem(STORES[i]);

      p1.add(dateLabel);
      p1.add(date);

      p1.add(timeLabel);
      p1.add(time);

      p1.add(statusLabel);
      p1.add(status);
      status.setFont(new Font("Monospaced", Font.BOLD, 12) );
      status.setBackground(Color.white);

      p2.add(submitButton);
      p2.add(clearButton);

      // used for dates
      GregorianCalendar  d = new GregorianCalendar();
      int month = d.get(Calendar.MONTH);
      int day   = d.get(Calendar.DATE);
      int year   = d.get(Calendar.YEAR);
      int day_name = d.get(Calendar.DAY_OF_WEEK)-1;

      date.addItem("Select a date for pick-up");

      // This needs to be fixed so it wraps
      for(int i = 0; i <= 4; i++)
      {  
         String s1 = new String( DAYS[(day_name)] + ", " 
                            + MONTHS[d.get(Calendar.MONTH)] + " " 
                            + (d.get(Calendar.DATE)) + ", " 
                            + d.get(Calendar.YEAR));
         date.addItem(s1);
         day_name = (day_name >= 6 ? 0 : day_name+1);
         d.set(d.get(Calendar.YEAR),d.get(Calendar.MONTH),
               d.get(Calendar.DATE)+1);
      }

      time.addItem("Select time for pick-up");
      time.addItem(" 9:00 AM");
      time.addItem("10:00 AM");
      time.addItem("11:00 AM");
      time.addItem("12:00 PM");
      time.addItem(" 1:00 PM");
      time.addItem(" 2:00 PM");
      time.addItem(" 3:00 PM");
      time.addItem(" 4:00 PM");
      time.addItem(" 5:00 PM");
      time.addItem(" 6:00 PM");
      time.addItem(" 7:00 PM");
      time.addItem(" 8:00 PM");

      // Register TextFields and Buttons with ActionListener
      prescriptionID.addActionListener(this);
      submitButton.addActionListener(this);
      clearButton.addActionListener(this);

      // Register ComboBoxes with ItemListener
      store.addItemListener(this);  
      date.addItemListener(this);
      time.addItemListener(this);

      // Register components with KeyListener
      prescriptionID.addKeyListener(this);
      store.addKeyListener(this);  
      date.addKeyListener(this);
      time.addKeyListener(this);
      submitButton.addKeyListener(this);

      // Add all panels
      add(prescriptionPanel);
      add(refillRequestPanel);
      add(refillPanel);

      setUpdate(false);
    }
  public void actionPerformed(ActionEvent ae)
    {
      Object source = ae.getSource();
 
      if(source == refreshPrescription)
        { 
	  refreshPrescriptions();
        }
      else if(source == refreshRefillRequest)
        {
	  refreshRequests();
        }
      else if(source == prescriptionID)
        {  
          status.setText("Select Store");
          store.requestFocus();
          return;
        }

      else if(source == submitButton)
        {        
          int check = -1;
          
          // check if form is completed
          if(prescriptionID.getText().equals(""))
            {
              status.setForeground(Color.red);
              status.setText(" Please select a prescription from the table");
              prescriptionID.requestFocus();
              return;
            }

          if(((String)store.getSelectedItem()).equals("Select a store for pick-up"))
            {
              status.setForeground(Color.red);
              status.setText(" Please select a pick-up store");
              store.requestFocus();
              return;
            }

          if(((String)date.getSelectedItem()).equals("Select a date for pick-up"))
            {
              status.setForeground(Color.red);
              status.setText(" Please select a date for pick-up");
              date.requestFocus();
              return;
            }

          if(((String)time.getSelectedItem()).equals("Select time for pick-up"))
            {
              status.setForeground(Color.red);
              status.setText(" Please select a time for pick-up");
              time.requestFocus();
              return;
            }

          // form is complete so 
          // disable more requests until this one handled
          submitButton.setEnabled(false);
          clearButton.setEnabled(false); 

          // put in a call to PRServlet
          if(!isUpdate())
           {
             check = ClientActivities.requestRefill(new Long(getCustNo()), prescriptionID.getText(), 
                                        String.valueOf(store.getSelectedIndex()), 
                                        (String)date.getSelectedItem(), (String)time.getSelectedItem());
	     prescriptionID.setText("");
             store.requestFocus();
             status.setForeground(Color.blue);
             refreshPrescriptions();
           }
          else
           {
             check = ClientActivities.updateRequest(new Long(getCustNo()), prescriptionID.getText(), 
                                        String.valueOf(store.getSelectedIndex()), 
                                        (String)date.getSelectedItem(), (String)time.getSelectedItem());
	     clearRequestForm();
             status.setForeground(Color.blue);
           }
          decode(check);
          refreshRequests();
	  submitButton.setEnabled(true);
          clearButton.setEnabled(true);
       }  
     else if(source == clearButton)
       {
         clearRequestForm();
       }
    }

  //*****************************************************
  // Decode status returned from ClientActivities.requestRefill()
  //*****************************************************
  private void decode(int refillStatus)
   {
     switch(refillStatus)
      {
        case ClientActivities.PR_OK: 
          status.setText("Request submitted.");
          break;
        case ClientActivities.PR_EXP: 
          status.setText("Prescription expired.");
          break;
        case ClientActivities.PR_NON: 
          status.setText("No more refills left.");
          break;
        case ClientActivities.PR_INV: 
          status.setText("Invalid prescription number.");
          break;
        case ClientActivities.PR_DUP: 
          status.setText("A refill has already been requested.");
          break;
        default: 
          status.setText("Error processing request. Please try again.");
          break;
      }
    } // end decode  

  private void refreshRequests()
   {
     refreshRefillRequest.setEnabled(false);
     rModel.getData(new Long(getCustNo()));
     refreshRefillRequest.setEnabled(true);
   }
  private void refreshPrescriptions()
   {
     refreshPrescription.setEnabled(false);
     pModel.getData(new Long(getCustNo()));
     refreshPrescription.setEnabled(true);
   }
  private void clearRequestForm()
   {
     prescriptionID.setText("");
     submitButton.setText("Submit Request");
     prescriptionID.setText("");
     store.setSelectedIndex(0);
     date.setSelectedIndex(0);
     time.setSelectedIndex(0);
     status.setForeground(Color.black);
     status.setText("Fill Form and press Submit Request");
     setUpdate(false);
   }
  //*******************************************************************
  // Populate prescription id field in refill request form when double
  // click event received on prescription table
  //*******************************************************************
  private void refillPrescription(int row, PrescriptionTableModel ptm)
   {
     if(row == -1)     
      {
        // No row selected
	return;
      }

     Prescription presc = ptm.getPrescription(row);
     prescriptionID.setText(presc.getPrescriptionNo());
   }
  //*****************************************************
  // Populate refill request form with row data when
  // double click event received on request table
  //*****************************************************
  private void editRequestRow(int row, RefillRequestTableModel rtm)
   {
     if(row == -1)
      {
        // No row selected
        return;
      }
    
     RefillRequest req = rtm.getRequest(row);
     GregorianCalendar gCal;
     java.util.Date pDate;
     java.util.Date cDate;
     SimpleDateFormat sdf = new SimpleDateFormat(PrescriptionPanel.DATE_FORMAT);
     ParsePosition pos = new ParsePosition(0);
     
     if(!req.getStatus().equals("R") && !req.getStatus().equals("r"))
      {
        // Inform user that the request can no longer be edited
        System.out.println("Request cannot be edited.");
        return;
      }

     // Populate form
     prescriptionID.setText(req.getPrescriptionNo());

     try
      {
        store.setSelectedIndex((Integer.parseInt(req.getPharmacy())));
      }
     catch(NumberFormatException nfe)
      { 
        nfe.printStackTrace();
      }

     try
      { 
        gCal = new GregorianCalendar();
        pDate = sdf.parse(req.getPickupDate(), pos);
        cDate = gCal.getTime();
        
        if(cDate.after(pDate))
         {
           date.setSelectedIndex(0);
           status.setForeground(Color.red);
           status.setText("The pickup date has passed. Select a new date.");
           date.requestFocus(); 
         }
        else
         {
           // Pickup date still valid
           gCal.setTime(pDate);
           String dt = new String(DAYS[(gCal.get(Calendar.DAY_OF_WEEK)-1)] + ", " 
                            + MONTHS[gCal.get(Calendar.MONTH)] + " " 
                            + (gCal.get(Calendar.DATE)) + ", " 
                            + gCal.get(Calendar.YEAR));

           date.setSelectedItem(dt);
         }
        gCal.setTime(pDate);
        int pTimeHour = gCal.get(Calendar.HOUR);
        int pTimeMin = gCal.get(Calendar.MINUTE);
        int pTimeApm = gCal.get(Calendar.AM_PM);
        String pTime = ((pTimeHour < 10) ? (" " + pTimeHour + ":") : (pTimeHour + ":"))
                   + ((pTimeMin < 10) ? ("0" + pTimeMin + " ") : (pTimeMin + " "))
                   + ((pTimeApm == Calendar.AM) ? "AM" : "PM");
        time.setSelectedItem(pTime);
      }
     catch(Exception e)
      {
        e.printStackTrace();
      }
     submitButton.setText("Update Request");
     setUpdate(true);
   }

  //*****************************************************
  // Other listener actions
  //*****************************************************

  // Implement itemStateChanged() for ItemListener
  public synchronized void itemStateChanged(ItemEvent event)
   {
      Object source = event.getSource();

      if(event.getStateChange() == ItemEvent.SELECTED)
      {
         if(source == store)
         {
            ;
         }

         if(source == date)
         {
            ;
         }

         if(source == time)
         {
            ;
         }
      }
   }
  public void keyReleased(KeyEvent event)
    {
    }
  public void keyPressed(KeyEvent event) 
    {
      ActionEvent ae = new ActionEvent(event.getSource(), 
                            ActionEvent.ACTION_PERFORMED, 
                            submitButton.getActionCommand());

      if(event.getKeyCode() == KeyEvent.VK_ENTER)
        {
          if(event.getSource() == submitButton)
            submitButton.dispatchEvent(ae);
 
          else if(event.getSource() == time)
            submitButton.requestFocus();

          else if(event.getSource() == prescriptionID)
            {
              event.getComponent().transferFocus();
              prescriptionID.select(0,0);
            }
          else
            event.getComponent().transferFocus();
       }
    }
  public void keyTyped(KeyEvent event)
    {
    }
  private void setCustNo(long no)
    {
      custNo = no;
    }
  private long getCustNo()
    {
      return custNo;
    }
  private void setUpdate(boolean b)
    {
      isUpdate = b;
    }
  private boolean isUpdate()
    {
      return isUpdate;
    }
}


