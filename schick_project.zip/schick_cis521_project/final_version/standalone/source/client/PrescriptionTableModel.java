//********************************************************************************
//         File: PrescriptionTableModel.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To provide a JTable table model for displaying Prescritions.
//
//********************************************************************************

import java.util.Vector;

public class PrescriptionTableModel extends PRTableModel
{ 
  private static Prescription p = new Prescription();

  public PrescriptionTableModel()
   {
     super(p.getHeaders(), p.getPropertyTypes(), p.getPropertyCount());
   }
  public void getData(Long customerNo)
   {
     Vector newPrescriptions = new Vector();

     newPrescriptions = ClientActivities.getPrescriptions(customerNo);

     clearTable();

     // If there are prescriptions add them to the table
     while(!newPrescriptions.isEmpty())
       {
         addObject((Prescription)newPrescriptions.remove(0));
       }
     
     fireTableDataChanged();
   }
  // Get a prescription from the table
  public Prescription getPrescription(int row)  
   {
     return (Prescription)getObject(row);
   }
}
