//********************************************************************************
//         File: RefillRequest.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To represent a refill request in a JTable. This class provides 
//               methods which simplify the extraction of refill request
//               data for placement in a JTable environment.
//
//********************************************************************************

import java.util.*;

public class RefillRequest implements PRTableObject
{
  // Property numbers
  private static final int PROP_COUNT = 6;
  public static final int PRESCRIPTION_NO = 0;
  public static final int REFILL_NO = 1;
  public static final int REQUEST_DATE = 2;
  public static final int PICKUP_DATE = 3;
  public static final int PHARMACY = 4;
  public static final int STATUS = 5;

  // Attributes of a refill request
  private String prescriptionNo;
  private String refillNo;
  private String requestDate;
  private String pickupDate;
  private String pharmacy;
  private String status;
  private boolean prescriptionNoEditable;
  private boolean refillNoEditable;
  private boolean requestDateEditable;
  private boolean pickupDateEditable;
  private boolean pharmacyEditable;
  private boolean statusEditable;

  // Names of each property
  private static String[] propNames = new String[]{"Prescription No.", "Refill No.", 
                                    "Request Date", "Pickup Date", "Pharmacy", "Status"};

  // Type of each property
  private static Class[] propTypes = new Class[]{String.class, String.class, 
                                     String.class, String.class, String.class, String.class};
  

  public RefillRequest()
   {
     for(int i=0;i < PROP_COUNT;i++)
       {
         setProperty(i, new String(""));
       }
     setPrescriptionNoEditable(false);
     setRefillNoEditable(false);
     setRequestDateEditable(false);
     setPickupDateEditable(false);
     setPharmacyEditable(false);
     setStatusEditable(false);
   }
  public RefillRequest(String data)
   {
     StringTokenizer p = new StringTokenizer(data, "|");

     for(int i=0;i < PROP_COUNT;i++)
       {
         setProperty(i, new String(""));
       }

     for(int i=0;p.hasMoreElements() && i < PROP_COUNT;i++)
       {
         setProperty(i, p.nextToken());
       }
     setPrescriptionNoEditable(false);
     setRefillNoEditable(false);
     setRequestDateEditable(false);
     setPickupDateEditable(false);
     setPharmacyEditable(false);
     setStatusEditable(false);
   }
  // Get the header for each property
  public String[] getHeaders()
   {
     return propNames;
   }
  // Get the type of each property
  public Class[] getPropertyTypes()
   {
     return propTypes;
   }
  // Get the number of properties
  public int getPropertyCount()
   {
     return PROP_COUNT;
   }
  // Set a property by its number
  public void setProperty(int num, String value)
   {
     switch(num)
       {
         case PRESCRIPTION_NO:    setPrescriptionNo(value);
                                  break;
         case REFILL_NO:          setRefillNo(value);
                                  break;
         case REQUEST_DATE:       setRequestDate(value);
                                  break;
         case PICKUP_DATE:        setPickupDate(value);
                                  break;
         case PHARMACY:           setPharmacy(value);
                                  break;
         case STATUS:             setStatus(value);
                                  break;
         default:                 System.err.println("Unknown RefillRequest property: " + num);
                                  break;
       }
   }
  // Get a property by its number
  public String getProperty(int num)
   {
     switch(num)
       {
         case PRESCRIPTION_NO:    return getPrescriptionNo();
                                
         case REFILL_NO:          return getRefillNo();
                                  
         case REQUEST_DATE:       return getRequestDate();
                                  
         case PICKUP_DATE:        return getPickupDate();
                                  
         case PHARMACY:           return getPharmacy();

         case STATUS:             return getStatus();
                                  
         default:                 System.err.println("Unknown RefillRequest property: " + num);
                                  return new String("");
                                 
       }
   }
  // Find out if a property is editable or not by its number
  public boolean isPropertyEditable(int num)
   {
     switch(num)
       {
         case PRESCRIPTION_NO:    return isPrescriptionNoEditable();
                                
         case REFILL_NO:          return isRefillNoEditable();
                                  
         case REQUEST_DATE:       return isRequestDateEditable();
                                  
         case PICKUP_DATE:        return isPickupDateEditable();
                                  
         case PHARMACY:           return isPharmacyEditable();

         case STATUS:             return isStatusEditable();
                                  
         default:                 return false;
                                 
       }
   }
  public boolean isPrescriptionNoEditable()
   {
     return prescriptionNoEditable;
   }
  public void setPrescriptionNoEditable(boolean b)
   {
     prescriptionNoEditable = b;
   }
  public boolean isRefillNoEditable()
   {
     return refillNoEditable;
   }
  public void setRefillNoEditable(boolean b)
   {
     refillNoEditable = b;
   }
  public boolean isRequestDateEditable()
   {
     return requestDateEditable;
   }
  public void setRequestDateEditable(boolean b)
   {
     requestDateEditable = b;
   }
  public boolean isPickupDateEditable()
   {
     return pickupDateEditable;
   }
  public void setPickupDateEditable(boolean b)
   {
     pickupDateEditable = b;
   }
  public boolean isPharmacyEditable()
   {
     return pharmacyEditable;
   }
  public void setPharmacyEditable(boolean b)
   {
     pharmacyEditable = b;
   }
  public boolean isStatusEditable() 
   {
     return statusEditable;
   }
  public void setStatusEditable(boolean b)
   {
     statusEditable = b;
   }
  public void setPrescriptionNo(String num)
   {
     prescriptionNo = num;
   }
  public String getPrescriptionNo()
   {
     return prescriptionNo;
   } 
  public void setRefillNo(String r)
   {
     refillNo = r;
   }
  public String getRefillNo()
   {
     return refillNo;
   } 
  public void setRequestDate(String d)
   {
     requestDate = d;
   }
  public String getRequestDate()
   {
     return requestDate;
   } 
  public void setPickupDate(String d)
   {
     pickupDate = d;
   }
  public String getPickupDate()
   {
     return pickupDate;
   } 
  public void setPharmacy(String p)
   {
     pharmacy = p;
   }
  public String getPharmacy()
   {
     return pharmacy;
   } 
  public void setStatus(String s)
   {
     status = s;
   }
  public String getStatus()
   {
     return status;
   } 
  public String toString()
   {
     return prescriptionNo + "|" + refillNo + "|" + requestDate + "|" + pickupDate + "|" 
            + pharmacy + "|" + status;
   }
}