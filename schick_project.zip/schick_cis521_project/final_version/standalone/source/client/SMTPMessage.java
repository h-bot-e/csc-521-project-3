//********************************************************************************
//         File: SMTPMessage.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: This class contains constants used when sending message to and
//               from SMTPServlet.
//
//********************************************************************************

public class SMTPMessage
{
  public static final int INVALID_PARAM = 1; // invalid parameter in message
  public static final int SEND_OK = 2; // message was sent successfully
  public static final int SEND_ERROR = 3; // error sending message
}