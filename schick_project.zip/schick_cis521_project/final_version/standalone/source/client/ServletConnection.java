//********************************************************************************
//         File: ServletConnection.java
//       Author: Joe Schick
//         Date: 11/05/03
//     Computer: PCs and Suns
//      Purpose: To simplify communications between an applet and servlet using 
//               a URLConnection to send and receive data using http. Data is 
//               sent to an HttpServlet via a POST.
//
//********************************************************************************

import java.io.*;
import java.net.*;

public class ServletConnection
{
  private String sUrl;
  private URLConnection conn;
  private ObjectInputStream ois;
  private ObjectOutputStream oos;
  private boolean output;
  private boolean input;
  private boolean connected;
  
  public ServletConnection(String url)
   {
     sUrl = url;
     setConnected(false);
     setOutput(false);
     setInput(false);
   }
  public boolean openConnection()
   {
     URL url;
     if(!isConnected())
      {
        try
         {
	   url = new URL(sUrl);
           conn = url.openConnection();
           conn.setDoInput(true);
           conn.setDoOutput(true);
           conn.setUseCaches(false);
           conn.setDefaultUseCaches(false);
           conn.setRequestProperty("Content-Type", "application/octet-stream");
           setConnected(true);
           return true;
         }
        catch(MalformedURLException me)
	 {
	   me.printStackTrace();
	 }
        catch(IOException ioe)
         {
           ioe.printStackTrace();
         }
      }
     return false;
   }
  public boolean writeObject(Object obj)
   {
     if(isConnected())
      {
        try
         {
	   if(!hasOutput())
            {
              oos = new ObjectOutputStream(conn.getOutputStream());
              setOutput(true);
            }
           oos.writeObject(obj);
           oos.flush();
           return true;
         }
        catch(IOException ioe)
         {
           ioe.printStackTrace();
         }
      }
     return false;
   }
  public Object readObject() throws IOException, ClassNotFoundException
   {
     Object obj = new Object();
     if(isConnected())
      {
        if(!hasInput())
         {
           ois = new ObjectInputStream(conn.getInputStream());
           setInput(true);
         }
        obj = ois.readObject();
      }
     return obj;
   }
  private void setConnected(boolean b)
   {
     connected = b;
   }
  public boolean isConnected()
   {
     return connected;
   } 
  private void setOutput(boolean b)
   {
     output = b;
   }
  private boolean hasOutput()
   {
     return output;
   }
  private void setInput(boolean b)
   {
     input = b;
   }
  private boolean hasInput()
   {
     return input;
   }
}
