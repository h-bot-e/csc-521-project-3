//**************************************************************
//     File:    User.java
//      Dir:    cis521/fred_02
// Compiler:    java 1.2
//     Date:    May 2002
//   Author:    HGG
//  Purpose:    to create the User class for Customers only in the
//              Fred project
//**************************************************************

public class User
{
   private String userId;
   private String userName;
   private String userType;
   
   public User( String id, String name, String type)
   {
     userId = id;
     userName = name;
     userType = type;
   }

   public String getUserId()
   {
     return userId;
   }

   public String getUserName()
   {
     return userName;
   }

   public String getUserType()
   {
     return userType;
   }
 
   public String toString()
   {
      return userId + " " + userName + " " + userType;
   }

}
