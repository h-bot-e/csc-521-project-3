//********************************************************************************
//         File: Oracle8Connection.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: This class provides a getConnection method for the creation 
//               and retrieval of an oracle 8i connection. 
//
//********************************************************************************

import java.sql.*;
import oracle.jdbc.pool.OracleDataSource;

public class Oracle8Connection extends DBConnection
{
  private static final String DRIVER_TYPE = "oci8";

  private OracleDataSource ods;
  private Connection conn;

  public Oracle8Connection()
   {
   }
  public Connection getConnection(String host, String databaseName, 
                         int port, String userName, String password) 
                           throws SQLException
   {
     try 
      {
        Class.forName ("oracle.jdbc.driver.OracleDriver").newInstance();
      } 
     catch (Exception e) 
      {
        System.out.println ("Could not load the driver"); 
      }

     //Create a OracleDataSource instance
     ods = new OracleDataSource();
 
     //Sets the driver type
     ods.setDriverType(Oracle8Connection.DRIVER_TYPE);
  
     // Sets the database server name
     ods.setServerName(host);
 
     // Sets the database name
     ods.setDatabaseName(databaseName);
 
     // Sets the port number
     ods.setPortNumber(port);
 
     // Sets the user name
     ods.setUser(userName);
   
     // Sets the password
     ods.setPassword(password);
  
     // Gets a connection
     conn = ods.getConnection();

     return conn;
   }
}
