//********************************************************************************
//         File: PRServlet.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To handle http requests made from Fred's Online Pharmacy using a
//               PRBusiness instance.
//
//********************************************************************************

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class PRServlet extends HttpServlet
{
  public void init(ServletConfig config) throws ServletException
   {
     super.init(config);
     log("PRServlet inited");
   }
  public void doPost(HttpServletRequest req, HttpServletResponse res)
                         throws ServletException, IOException
   {
     String message = new String();
     ServletClientConnection conn = new ServletClientConnection(req, res);
     PRBusiness business = new PRBusiness();

     try
      {
        // Get the message associated with the http request
        message = (String)conn.readObject();
        System.out.println("PRServlet: Received: " + message);
        message = business.processMessage(message);
        System.out.println("PRServlet: Sending: " + message);

        // Write a response to client
        if(!conn.writeObject(message))
         {
           System.out.println("PRServlet: Error writing to client.");
         }
      }
     catch(IOException ioe)
      {
        System.out.println(ioe);
      }
     catch(ClassNotFoundException ioe)
      {
        System.out.println(ioe);
      }    
   }
  public void doGet(HttpServletRequest req, HttpServletResponse res)
                         throws ServletException, IOException
   {
     doPost(req, res);
   }
  public String getServletInfo()
   {
     return "Pharmacy Servlet version 1.0";
   }
}
