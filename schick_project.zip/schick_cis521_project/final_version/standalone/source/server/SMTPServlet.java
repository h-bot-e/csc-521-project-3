//***************************************************************************
//         File: SMTPServlet.java
//       Author: Joe Schick
//         Date: 11/12/03
//     Computer: PCs and Suns
//      Purpose: To define an http servlet which will
//               allow emails to be sent via SMTP.
//
//***************************************************************************

import java.io.*;
import java.util.*;
import javax.servlet.http.*;
import javax.servlet.*;
import javax.mail.*;
import javax.mail.internet.*;

public class SMTPServlet extends HttpServlet 
{
   /**
    * Source version.
    */
   public static String vcid = "$Id: SMTPServlet.java,v 1.7"
                         + "  2000/07/15 12:23:44 Hendrik Exp $";

   /**
    * Standard SMTP host.
    */
   protected String myHost = null;

   /**
    * Standard to address.
    */
   protected String myTo = null;

   /**
    * Standard bcc address.
    */
   protected String myBcc = null;

   /**
    * Standard from address.
    */
   protected String myFrom = null;

   /**
    * Standard subject.
    */
   protected String mySubject = null;

   /**
    * Standard body.
    */
   protected String myBody = null;

   /**
    * Servlet info.
    */
   public String getServletInfo()
   {
      return "MailServlet ($Id: SMTPServlet.java,v 1.7"
                          + " 2000/07/15 12:23:44 Hendrik Exp $)";
   }

   /**
    * Reads the initialization arguments and sets
    * the standard values for <code>host</code>, <code>to</code>,
    * <code>from</code>, <code>subject</code> and
    * <code>body</code>.<br>
    * Example:<br>
    * <xmp>
    * # SMTP servlet
    * servlet.smtp.code=weblication.Examples.SMTPServlet
    * servlet.smtp.initArgs=host=my.smtphost.de,from=mir,to=dir@my.smtphost.de
    * </xmp>
    *
    * @exception ServletException (is not thrown)
    */
   public void init(ServletConfig aConfig) throws ServletException
   {
      super.init(aConfig);
      myHost = getInitParameter("host");
      myTo = getInitParameter("to");
      myBcc = getInitParameter("bcc");
      myFrom = getInitParameter("from");
      mySubject = getInitParameter("subject");
      myBody = getInitParameter("body");
   }

   /**
    * Tests the existence of Host, From, To, Subject and Body.
    * If the hostname was not specified, it is assumed to
    * use the address of the server. If one of the other
    * parameters is missing, an error message is output.
    *
    * @exception ServletException (is not thrown)
    * @exception IOException in case writing fails.
    */
   public void doPost(HttpServletRequest req, HttpServletResponse res)
                                    throws ServletException, IOException
   {
     String message = new String();
     ServletClientConnection conn = new ServletClientConnection(req, res);
  
     try
      {
        message = (String)conn.readObject();
        System.out.println("SMTPServlet: Received: " + message);
      }
     catch(IOException ioe)
      {
        System.out.println(ioe);
      }
     catch(ClassNotFoundException ioe)
      {
        System.out.println(ioe);
      }          

      // read parameters
      StringTokenizer stm = new StringTokenizer(message, "|");
      String cTo;
      String cFrom;
      String cBcc;
      String cSubject;
      String cBody;
      String cHost;

      try
       {
         cTo = stm.nextToken();
         cFrom = stm.nextToken();
         cBcc = stm.nextToken();
         cSubject = stm.nextToken();
         cBody = stm.nextToken();
         cHost = stm.nextToken();
       }
      catch(NoSuchElementException nse)
       {
         message = SMTPMessage.INVALID_PARAM + "|invalid number of parameters";
         System.out.println("SMTPServlet: Sending: " + message);

         if(!conn.writeObject(message))
          {
            System.out.println("SMTPServlet: Error writing to client.");
          }
         return;
       }

      String from = (myFrom == null) ?  cFrom : myFrom;
      String to = (myTo == null) ? cTo : myTo;
      String bcc = (myTo == null) ? cBcc : myBcc;
      String subject = (mySubject == null) ? cSubject : mySubject;
      String body = (myBody == null) ? cBody : myBody;
      String host = (myHost == null) ? cHost : myHost;

      if(host == null)
       {
         host = req.getServerName();
       }
      
      // provide mail session
      Properties props = new Properties();
      props.put("mail.smtp.host",host);
      Session session = Session.getDefaultInstance(props,null);
      Message msg = new MimeMessage(session);    
      try
       {
	 // process to
         StringTokenizer st = new StringTokenizer(to," ,;");
         int length = st.countTokens();            
         InternetAddress[] toAddresses = new InternetAddress[length];
         for(int i = 0;st.hasMoreTokens();i++)
	  {
            toAddresses[i] = new InternetAddress(st.nextToken());
	  }

         // process bcc
         if(bcc != null)
          {
            StringTokenizer stbcc = new StringTokenizer(bcc," ,;"); 
            int bccLen = stbcc.countTokens();            
            InternetAddress[] bccAddresses = new InternetAddress[bccLen];
            for(int i = 0;stbcc.hasMoreTokens();i++)
             {
               bccAddresses[i] = new InternetAddress(stbcc.nextToken());
             }
            msg.setRecipients(Message.RecipientType.BCC, bccAddresses);  
          }
         if((String.valueOf(subject).equals("null")) || (String.valueOf(subject).trim().equals("")))
          {
            subject = "<no subject>";
          }
         msg.setFrom(new InternetAddress(from));
         msg.setSubject(subject);
         msg.setRecipients(Message.RecipientType.TO,toAddresses);
         msg.setContent(body,"text/plain");

         // send
         Transport.send(msg);
         message = SMTPMessage.SEND_OK + "|message sent";
         System.out.println("SMTPServlet: Sending: " + message);

         if(!conn.writeObject(message))
          {
            System.out.println("SMTPServlet: Error writing to client.");
          }
         return;
       }
      catch(MessagingException mex)
       {
	 System.out.println(mex);
         message = SMTPMessage.SEND_ERROR + "|error sending message";
         System.out.println("SMTPServlet: Sending: " + message);

         if(!conn.writeObject(message))
          {
            System.out.println("SMTPServlet: Error writing to client.");
          }
         return;
       }
   }
   public void doGet(HttpServletRequest req, HttpServletResponse res)
                                   throws ServletException, IOException
   {
     doPost(req, res);
   }
}

// end of class
