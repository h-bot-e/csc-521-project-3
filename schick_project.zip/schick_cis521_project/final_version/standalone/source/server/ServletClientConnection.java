//********************************************************************************
//         File: ServletClientConnection.java
//       Author: Joe Schick
//         Date: 11/05/03
//     Computer: PCs and Suns
//      Purpose: To simplify communications between a servlet and an applet using
//               the input and output streams associated with the HttpRequest
//               and HttpResponse objects passed to the doPost method of an
//               HttpServlet.
//
//********************************************************************************

import java.io.*;
import javax.servlet.*;

public class ServletClientConnection
{
  private ServletRequest req;
  private ServletResponse res;
  private ObjectInputStream ois;
  private ObjectOutputStream oos;
  private boolean output;
  private boolean input;

  public ServletClientConnection(ServletRequest request, ServletResponse response)
                                                                   
   {
     req = request;
     res = response;
     setOutput(false);
     setInput(false);
   }
  public boolean writeObject(Object obj)
   {
     try
      {
	if(!hasOutput())
	 {
	   oos = new ObjectOutputStream(res.getOutputStream());
           setOutput(true);
	 }
        oos.writeObject(obj);
        oos.flush();
	  return true;
      }
     catch(IOException ioe)
      {
        ioe.printStackTrace();
	  return false;
      }
   }
  public Object readObject() throws IOException, ClassNotFoundException
   {
     Object obj;
     if(!hasInput())
      {
        ois = new ObjectInputStream(req.getInputStream());
        setInput(true);
      }
     obj = ois.readObject();
     return obj;
   }
  private void setOutput(boolean b)
   {
     output = b;
   }
  private boolean hasOutput()
   {
     return output;
   }
  private void setInput(boolean b)
   {
     input = b;
   }
  private boolean hasInput()
   {
     return input;
   }
}
