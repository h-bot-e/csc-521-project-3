Running the server

   - type "java PRServer 8018 > PRServer.log &"

   Note: Any port can be used (8018 is the port) but the port number must be changed
         in ClientActivities.java.

Accessing the software online

   - To access the software online go to http://unixweb.kutztown.edu/~schi3008/cis521/Fred.html
