//********************************************************************************
//         File: ClientActivities.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To serve as a single access point for a client to communicate
//               with the server. This class includes methods for all of 
//               Fred's business activities.
//
//********************************************************************************

import java.util.*;
import java.lang.*;

public class ClientActivities
{
  // Server Message Tags
  public static final int SERVER = 1; // Server down

  // Login message tags
  public static final String LOGIN_NOK = "invalid"; // login failed
  public static final String LOGIN_SUS = "suspended"; // account suspended
  public static final String LOGIN_SERVER = "server error"; // Server down or error

  // Refill message tags
  public static final int PR_OK =  21;  // request succeeded
  public static final int PR_EXP = 22; // prescription expired
  public static final int PR_NON = 23; // no more refills
  public static final int PR_INV = 24; // invalid prescription number
  public static final int PR_DUP = 25; // already requested

  // List Prescription message tags
  public static final int LP     = 40; // request prescription list
  public static final int LP_NON = 41; // no recent prescriptions

  public ClientActivities()
   {
   }
  // Get all (not expired) prescriptions for a particular customer
  public static Vector getPrescriptions(Long customerNo)
   {
     Vector data = new Vector();
     PRClient client = new PRClient();
     Prescription p;
     StringTokenizer pData;
     String parts = " ";
     int numPrescriptions = 0;

     if(client.openConnection("pooh.kutztown.edu", 8018)) 
       {  
         // make the message
         String [] mess = {customerNo.toString()};
         PRMessage prescriptionMessage = new PRMessage(PRMessage.LP, mess);
         client.sendMessage(prescriptionMessage.toString());
         if(client.receiveMessage())
           {  // decode reply
              PRMessage reply = new PRMessage(client.getReply());
              
              if(reply.getTag() == PRMessage.LP_OK)
                {
                  pData = new StringTokenizer(client.getReply(), "|");
                  client.closeConnection();
                  
                  numPrescriptions = ((pData.countTokens() - 1) / 8);

                  // Move past tag
                  if(pData.hasMoreTokens())
                    { 
                      parts = pData.nextToken();
                    }
                  for(int i=0;i < numPrescriptions;i++)
                    {
                      for(int j=0;j < 8;j++)
                        {
                          if(j > 0)
                           {
                             parts = parts + "|" + pData.nextToken();
                           }
                          else
                           {
                             parts = pData.nextToken();
                           }
                        } 
                      p = new Prescription(parts);
                      data.add(p);
                    }
                }
           }
         client.closeConnection();
       }
     return data;
   }
  // Get all open requests for a particular customer
  public static Vector getRefillRequests(Long customerNo)
   {
     Vector data = new Vector();
     PRClient client = new PRClient();
     RefillRequest r;
     StringTokenizer rData;
     String parts = " ";
     int numRequests = 0;

     if(client.openConnection("pooh.kutztown.edu", 8018)) 
       {  
         // make the message
         String [] mess = {customerNo.toString(), PRMessage.CREATOR};
         PRMessage refReqMessage = new PRMessage(PRMessage.LR, mess);
         client.sendMessage(refReqMessage.toString());
         if(client.receiveMessage())
           {  // decode reply
              PRMessage reply = new PRMessage(client.getReply());
              
              if(reply.getTag() == PRMessage.LR_OK)
                {
                  rData = new StringTokenizer(client.getReply(), "|");
                  client.closeConnection();
                  
                  numRequests = ((rData.countTokens() - 1) / 6);

                  // Move past tag
                  if(rData.hasMoreTokens())
                    { 
                      parts = rData.nextToken();
                    }
                  for(int i=0;i < numRequests;i++)
                    {
                      for(int j=0;j < 6;j++)
                        {
                          if(j > 0)
                           {
                             parts = parts + "|" + rData.nextToken();
                           }
                          else
                           {
                             parts = rData.nextToken();
                           }
                        } 
                      r = new RefillRequest(parts);
                      data.add(r);
                    }
                }
           }
         client.closeConnection();
       }
     return data;     
   }
  // Request a refill - returns status constant
  public static synchronized int requestRefill(Long customerNo, String prescriptionNo, String store, String date, String time)
   {
     PRClient client = new PRClient();

     if(client.openConnection("pooh.kutztown.edu", 8018)) 
       {  
         // make the message
         String [] mess = { customerNo.toString(),
                            prescriptionNo,
                            store,
                            ClientActivities.parseDate(date, time),
                            PRMessage.CREATOR
                          };
         PRMessage refillMessage = new PRMessage(PRMessage.PR, mess);
         client.sendMessage(refillMessage.toString());
         if(client.receiveMessage())
           {  // decode reply
              PRMessage reply = new PRMessage(client.getReply());
              client.closeConnection();              

              // Map constants
              switch(reply.getTag())
               {
                 case PRMessage.PR_OK: return ClientActivities.PR_OK;
                 case PRMessage.PR_EXP: return ClientActivities.PR_EXP;
                 case PRMessage.PR_NON: return ClientActivities.PR_NON;
                 case PRMessage.PR_INV: return ClientActivities.PR_INV;
                 case PRMessage.PR_DUP: return ClientActivities.PR_DUP;
                 default: return ClientActivities.SERVER;
               }
           }
         client.closeConnection();
       }
     return ClientActivities.SERVER;
   }
  // Login
  public static User verifyLogin(String user, String pass)
   {
     PRClient client = new PRClient();
     StringTokenizer parts;
     String userId;
     String fName;
     String lName;
     String uType;
     String replyStr;

     if(client.openConnection("pooh.kutztown.edu", 8018)) 
       {  
         // make the message
         String [] mess = {user, pass};
         PRMessage loginMessage = new PRMessage(PRMessage.LOGIN, mess);
         client.sendMessage(loginMessage.toString());
         if(client.receiveMessage())
           {  // decode reply
              replyStr = client.getReply();
              PRMessage reply = new PRMessage(replyStr);
              client.closeConnection();

              switch(reply.getTag())
               {
                 case PRMessage.LOGIN_OK:
                   parts = new StringTokenizer(replyStr, "|");
                   try
                     {
                       userId = parts.nextToken();  // skip past tag
                       userId = parts.nextToken();
                       lName = parts.nextToken();
                       fName = parts.nextToken();
                       uType = parts.nextToken();
                     }
                   catch(Exception e)
                     {
                       return new User(ClientActivities.LOGIN_SERVER, " ", " ");
                     }
                   return new User(userId, fName + " " + lName, uType);
                 case PRMessage.LOGIN_NOK: 
                   return new User(ClientActivities.LOGIN_NOK, " ", " ");
                 case PRMessage.LOGIN_SUS: 
                   return new User(ClientActivities.LOGIN_SUS, " ", " ");
                 default: 
                   return new User(ClientActivities.LOGIN_SERVER, " ", " ");
               }
           }
         client.closeConnection();
       }
     return new User(ClientActivities.LOGIN_SERVER, " ", " ");
   }
     
  //*****************************************************
  // ParseDate - puts a date into Oracle compatible format
  //*****************************************************
  // the following is used later for Oracle Date
  // it is compatible with Oracle's to_date function
  // as to_date( String, 'MONTH DD YYYY HH:SS AM');
  private static String parseDate(String d, String t)
   {
      String day = new String("");
      String date = new String("");
      String year = new String("");
      String pickupDate = new String("");
      StringTokenizer strings = new StringTokenizer(d, ",");

      day = strings.nextToken();
      date = strings.nextToken();
      year = strings.nextToken();

      date = date.trim();
      t = t.trim();

      pickupDate = date + year + " " + t;
   
      return pickupDate;
   }
}