//********************************************************************************
//         File: CustomerPanel.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To organize all the actions available to a customer of Fred's 
//               pharmacy using a JTabbedPane.
//
//********************************************************************************

import javax.swing.*;
import java.awt.*;


public class CustomerPanel extends JPanel
{
  private long custNo;
  private JTabbedPane jtp;
  private JPanel customerPanel;
  private JPanel prescriptionPanel;
  private JPanel productPanel;
  private JPanel helpPanel;
  private PrescriptionPanel prescriptionUI;
 
  public CustomerPanel(long customerNo)
    {
      super();
      setLayout(new BorderLayout());
      setBackground(Color.white);

      jtp = new JTabbedPane();
      prescriptionUI = new PrescriptionPanel(customerNo);
      customerPanel = new JPanel();
      customerPanel.setLayout(new BorderLayout());
      prescriptionPanel = new JPanel();
      prescriptionPanel.setLayout(new BorderLayout());
      productPanel = new JPanel();
      helpPanel = new JPanel();
     
      customerPanel.setBackground(new Color(95, 95, 175));
      prescriptionPanel.setBackground(new Color(221, 238, 255));
      prescriptionPanel.setOpaque(true);
      productPanel.setBackground(new Color(255, 255, 206));
      productPanel.setOpaque(true);
      helpPanel.setBackground(new Color(255, 213, 213));
      helpPanel.setOpaque(true);
   
      jtp.addTab("Prescriptions", prescriptionPanel);
      jtp.addTab("Products", productPanel);
      jtp.addTab("Help", helpPanel);
      jtp.setSelectedIndex(0);
      jtp.setBackgroundAt(0, new Color(202, 228, 255));
      jtp.setBackgroundAt(1, new Color(255, 255, 206));
      jtp.setBackgroundAt(2, new Color(255, 213, 213));
      jtp.setForegroundAt(0, Color.black);
      jtp.setForegroundAt(1, Color.black);
      jtp.setForegroundAt(2, Color.black);
  
      prescriptionPanel.add("Center", prescriptionUI);
      customerPanel.add("Center", jtp);
      add("Center", customerPanel);
    }
  private void setCustNo(long no)
    {
      custNo = no;
    }
  private long getCustNo()
    {
      return custNo;
    }
}