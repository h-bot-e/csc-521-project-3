//*********************************************************************************
//         File: PRBusiness.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To process all messages received from Fred's Pharmacy Online. 
//               This class is passed delimited strings via its processMessage
//               method, determines the type of message, and calls the appropriate
//               method to process the message. This class is thread-safe but 
//               could be modified to do this in a slightly more efficient fashion.
//
//*********************************************************************************

import java.util.*;
import java.sql.*;

public class PRBusiness
{
  private static final String HOST = "acad.kutztown.edu";
  private static final String DATABASE_NAME = "kudb";
  private static final int DATABASE_PORT = 1521;
  private static final String USERNAME = "fred2001";
  private static final String PASSWORD = "fred2001";

  private static final String PRESCRIPTION_OWNER = "SELECT customer_id, prescription_no "
       + "FROM gord7932.prescription "
       + "WHERE prescription_no = ? AND customer_id = ?";

  // Creator only exists in WHERE for testing purposes
  private static final String REQUEST_EXISTS = "SELECT prescription_no, status "
       + "FROM gord7932.request "
       + "WHERE prescription_no = ? AND (status = ? OR status = ?) AND creator = ?";

  private static final String PRESCRIPTION_EXP_NMR = "SELECT orig_refills_allowed, "
       + "(MAX(refill_no) + 1) refills_used "
       + "FROM gord7932.prescription p, gord7932.refill r "
       + "WHERE p.prescription_no = ? AND p.prescription_no = r.prescription_no "
       + "AND expiration_date > SYSDATE "
       + "GROUP BY orig_refills_allowed";

  private static final String INSERT_REFREQ = "INSERT INTO gord7932.request "
       + "VALUES (?, ?, SYSDATE, to_date(?, 'MONTH DD YYYY HH:SS AM'), ?, ?, ?, ?)";
 
  // Creator only exists in WHERE for testing purposes
  private static final String GET_REQUESTS = "SELECT prescription_no, refill_no, "
       + "request_date, pickup_date, pharmacy_no, status "
       + "FROM gord7932.request "
       + "WHERE customer_id = ? AND creator = ?";

  // All prescriptions that have not expired are returned
  private static final String GET_PRESCRIPTIONS = "SELECT p.prescription_no, drug_name, "
       + "doctor, instructions, prescription_date, quantity, orig_refills_allowed, "
       + "(max(refill_no) + 1) refills_used, expiration_date "
       + "FROM gord7932.prescription p, gord7932.refill r, gord7932.drug d "
       + "WHERE p.customer_id = ? AND p.drug_id = d.drug_id "
       + "AND p.prescription_no = r.prescription_no AND expiration_date > SYSDATE "
       + "GROUP BY p.prescription_no, drug_name, doctor, instructions, prescription_date, "
       + "quantity, orig_refills_allowed, expiration_date";

  private Connection conn;
  private Statement stmt;
  private ResultSet rset;
  private PreparedStatement pPOwner;
  private PreparedStatement pReqExists;
  private PreparedStatement pPExpNmr;
  private PreparedStatement pInsRequest;
  private PreparedStatement pGetRequests;
  private PreparedStatement pGetPrescriptions;
  
  public PRBusiness()
   {
     try
      {
        conn = new Oracle8Connection().getConnection(PRBusiness.HOST,
                                                  PRBusiness.DATABASE_NAME,
                                                  PRBusiness.DATABASE_PORT,
                                                  PRBusiness.USERNAME,
                                                  PRBusiness.PASSWORD);
        conn.setAutoCommit(false);
        stmt = conn.createStatement();
        pPOwner = conn.prepareStatement(PRBusiness.PRESCRIPTION_OWNER);
        pReqExists = conn.prepareStatement(PRBusiness.REQUEST_EXISTS);
        pPExpNmr = conn.prepareStatement(PRBusiness.PRESCRIPTION_EXP_NMR);
        pInsRequest = conn.prepareStatement(PRBusiness.INSERT_REFREQ);
        pGetRequests = conn.prepareStatement(PRBusiness.GET_REQUESTS);
        pGetPrescriptions = conn.prepareStatement(PRBusiness.GET_PRESCRIPTIONS);
      }
     catch(SQLException se)
      {
        se.printStackTrace();
      }
   }
  public synchronized String processMessage(String message)
   {
     String msg;
     StringTokenizer strTokens = new StringTokenizer(message, "|");
     int tag = new Integer(strTokens.nextToken()).intValue();
     
     msg = message.substring(message.indexOf('|') + 1);

     switch(tag)
      {
        case PRMessage.LOGIN: 
	  // Login message
          return verifyLogin(msg);
        case PRMessage.PR:
          return requestRefill(msg);
        case PRMessage.LR:
          return getRefillRequests(msg);
        case PRMessage.LP:
          return getPrescriptions(msg);
        default: // unknown message tag
          return PRMessage.SERVER_PR + "|unknown message tag";
             
      }  
   }
  private String verifyLogin(String msg)
   {
     StringTokenizer strTokens = new StringTokenizer(msg, "|");
     String user = strTokens.nextToken();
     String pass = strTokens.nextToken();

     String str = new String
            (" select  l.customer_id, last_name, first_name, status " + 
             " from gord7932.login l, gord7932.phar_customer c" +
             " where l.usercode = '" + user + "'" +
             " and l.password = '" + pass + "'"   +
             " and l.customer_id = c.customer_id ");
    
     try
      {
        rset = stmt.executeQuery(str);

        if(!rset.next())
         {
           // login failed
           System.out.println("Invalid Login ");
	   return msg = PRMessage.LOGIN_NOK + "|Invalid Login";
         }
        msg = PRMessage.LOGIN_OK + "|" + rset.getString(1) + "|" +
                         rset.getString(2) + "|" +
	                 rset.getString(3) + "|" + rset.getString(4);
        return msg;
      }
     catch(SQLException e)
      {
        e.printStackTrace();
      }
     return msg = PRMessage.SERVER_PR + "|database error";
   }
  private String requestRefill(String msg)
   {
     StringTokenizer strTokens = new StringTokenizer(msg, "|");
     long customerNo;
     long prescriptionNo;
     int store;
     String pickupDate;
     String creator;
 
     try
      {
        customerNo = Long.parseLong(strTokens.nextToken(), 10);
        prescriptionNo = Long.parseLong(strTokens.nextToken(), 10);
        store = Integer.parseInt(strTokens.nextToken(), 10);
        pickupDate = strTokens.nextToken();
        creator = strTokens.nextToken();
      }
     catch(Exception e)
      {
        e.printStackTrace();
        return PRMessage.SERVER_PR + "|invalid request";
      }
     
     // Check to see if customer owns the prescription and that it exists
     try
      {
        pPOwner.setLong(1, prescriptionNo);
        pPOwner.setLong(2, customerNo);
        rset = pPOwner.executeQuery();  
        if(!rset.next())
         {
           // customer does not own this prescription
           System.out.println("Customer does not own prescription.");
           return msg = PRMessage.PR_INV + "|Invalid prescription number";
         }      
      }
     catch(SQLException se1)
      {
        se1.printStackTrace();
        return PRMessage.SERVER_DB + "|database error 1";
      }

     // Check to see if the request already exists
     try
      {
        pReqExists.setLong(1, prescriptionNo);
        pReqExists.setString(2, "r");
        pReqExists.setString(3, "R");
        pReqExists.setString(4, creator);
        rset = pReqExists.executeQuery();
        if(rset.next())
         {
           // A refill has already been requested
           System.out.println("A refill has already been requested.");
           return msg = PRMessage.PR_DUP + "|Refill already requested";
         }
      }
     catch(SQLException se2)
      {
        se2.printStackTrace();
        return PRMessage.SERVER_DB + "|database error 2";
      }

     // Check to see that the prescription has not expired and has more refills
     try
      {
        pPExpNmr.setLong(1, prescriptionNo);
        rset = pPExpNmr.executeQuery();
     
        if(!rset.next())
         {
           // Prescription has expired
           System.out.println("Prescription has expired.");
           return msg = PRMessage.PR_EXP + "|prescription expired";
         }
      }
     catch(SQLException se3)
      {
        se3.printStackTrace();
        return PRMessage.SERVER_DB + "|database error 3";
      }
     // Prescription has not expired
     // Check refills left
     int refillsAllowed = -1;
     int usedRefills = -1;
     int check = -1;
     try
      {
        refillsAllowed = rset.getInt(1);
        usedRefills = rset.getInt(2);
      }
     catch(SQLException se4)
      {
        se4.printStackTrace();
        return msg = PRMessage.SERVER_DB + "|database error 4";
      }
     if(usedRefills >= refillsAllowed)
      {
        // No more refills
        System.out.println("No more refills.");
        return msg = PRMessage.PR_NON + "|no more refills";
      }

     // Request is good - insert request
     try
      {
        pInsRequest.setLong(1, prescriptionNo);
        pInsRequest.setInt(2, usedRefills);
        pInsRequest.setString(3, pickupDate);
        pInsRequest.setInt(4, store);
        pInsRequest.setString(5, "R");
        pInsRequest.setString(6, creator);
        pInsRequest.setLong(7, customerNo);
        check = pInsRequest.executeUpdate();
        if(check <= 0)
         {
           conn.rollback();
           return msg = PRMessage.SERVER_DB + "|database error 5";
         }
        conn.commit(); 
        System.out.println("Request submitted.");
        return msg = PRMessage.PR_OK + "|request submitted";
      }
     catch(SQLException se5)
      {
        se5.printStackTrace();
        try
         {
           conn.rollback();
         }
        catch(SQLException se6)
         {
           se6.printStackTrace();
         }
        return msg = PRMessage.SERVER_DB + "|database error 6";
      }
   }
  private String getRefillRequests(String msg)
   {
     StringTokenizer strTokens = new StringTokenizer(msg, "|");
     long customerNo;
     String creator;

     try
      {
        customerNo = Long.parseLong(strTokens.nextToken(), 10);
        creator = strTokens.nextToken();
      }
     catch(Exception e)
      {
        e.printStackTrace();
        return PRMessage.SERVER_PR + "|invalid request";
      }

     try
      {
        pGetRequests.setLong(1, customerNo);
        pGetRequests.setString(2, creator);
        rset = pGetRequests.executeQuery();
      
        if(!rset.next())
         {
           return PRMessage.LR_NON + "|no requested refills";
         }

        // Process first row
        msg = PRMessage.LR_OK + "|" + rset.getLong(1)
                              + "|" + rset.getInt(2)
                              + "|" + rset.getString(3)
                              + "|" + rset.getString(4)
                              + "|" + rset.getInt(5)
                              + "|" + rset.getString(6);

        while(rset.next())
         {
           msg = msg + "|" + rset.getLong(1)
                     + "|" + rset.getInt(2)
                     + "|" + rset.getString(3)
                     + "|" + rset.getString(4)
                     + "|" + rset.getInt(5)
                     + "|" + rset.getString(6);
         }
        return msg;
      }
     catch(SQLException se1)
      {
        return msg = PRMessage.SERVER_DB + "|database error";
      }
   }
  private String getPrescriptions(String msg)
   {
     StringTokenizer strTokens = new StringTokenizer(msg, "|");
     long customerNo;

     try
      {
        customerNo = Long.parseLong(strTokens.nextToken(), 10);
      }
     catch(Exception e)
      {
        e.printStackTrace();
        return PRMessage.SERVER_PR + "|invalid request";
      }

     try
      {
        pGetPrescriptions.setLong(1, customerNo);
        rset = pGetPrescriptions.executeQuery();
      
        if(!rset.next())
         {
           return PRMessage.LP_NON + "|no prescriptions";
         }

        // Process first row
        msg = PRMessage.LP_OK + "|" + rset.getLong(1)
                              + "|" + rset.getString(2)
                              + "|" + rset.getString(3)
                              + "|" + rset.getString(4)
                              + "|" + rset.getString(5)
                              + "|" + rset.getInt(6)
                              + "|" + (rset.getInt(7) - rset.getInt(8))
                              + "|" + rset.getString(9);

        while(rset.next())
         {
           msg = msg + "|" + rset.getLong(1)
                     + "|" + rset.getString(2)
                     + "|" + rset.getString(3)
                     + "|" + rset.getString(4)
                     + "|" + rset.getString(5)
                     + "|" + rset.getInt(6)
                     + "|" + (rset.getInt(7) - rset.getInt(8))
                     + "|" + rset.getString(9);
         }
        return msg;
      }
     catch(SQLException se1)
      {
        return msg = PRMessage.SERVER_DB + "|database error";
      }
   }
}