//********************************************************
//         File: PRClient.java
//       Author: HGG 
//         Date: January 2000
//     Modified: 12/03/03 - Joe Schick
//     Computer: PCs and KUNet
//     Compiler: jdk1.1.8 and jdk 1.2
//      Purpose: To develop the client side of the 
//               Client/Server portion of Fred's Pharmacy
//********************************************************

import java.io.*;
import java.net.*;

public class PRClient
{
   private Socket socket;
   private ObjectOutputStream oos;
   private ObjectInputStream ois;
   private boolean connectStatus = false; // not connected
   private String  reply;

   // Default Constructor
   public PRClient() {}

   public boolean isConnected()
   { 
      return connectStatus;
   }

   public String getReply()
   {
      return reply;
   }


   public boolean openConnection(String serverHost, int serverPort)
   {
      if( !isConnected())
      {
        try
        {
           socket = new Socket(serverHost, serverPort);
        }
        catch(IOException ioe)
        {

           System.err.println("Client-Can't create socket to server");
           ioe.printStackTrace();
           return(connectStatus = false);         }

        try
        {
           oos = new ObjectOutputStream(socket.getOutputStream());
           ois = new ObjectInputStream(socket.getInputStream());
        }
        catch(IOException ioe)
        {
           System.err.println("Client-Can't create object streams");
           ioe.printStackTrace();
           return(connectStatus = false); 
        }
        connectStatus = true; 
      }
      return connectStatus;
   }

   public void closeConnection()
   {
      if( !isConnected() ) return;
      sendMessage("Done");
      connectStatus = false;
      try 
      {
         oos.close();
         ois.close();
         socket.close();
         return;
      }
      catch(IOException ioe)
      {
         System.err.println("Client-Can't close client socket connection");
         ioe.printStackTrace();
         return;      
      }
   }

   public boolean sendMessage(String message)
   {
      try
      {
        oos.writeObject(message);
        oos.flush();
      }
      catch(IOException ioe)
      {
         System.err.println("Client: Can't write object stream to server");
         ioe.printStackTrace();
         return false;
      }   
      return true;
   }

   public boolean receiveMessage()
   {
      try
      {
         reply = (String) ois.readObject();
      }
      catch(IOException ioe)
      {
         System.err.println("Client: Can't read object stream from server");
         ioe.printStackTrace();
         return false;
      }
      catch(ClassNotFoundException ioe)
      {
         System.err.println("Client: Class Not found on readObject");
         ioe.printStackTrace();
         return false;
      }
      return true;
   }
}
