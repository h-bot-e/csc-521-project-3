//**************************************************************
//     File:    PRMessage.java
// Compiler:    java 1.2
//     Date:    January 2002
// Modified:    12/03/03 - Joe Schick
//   Author:    HGG
//  Purpose:    to create the class of Messages commonly used in 
//              Web Application for Fred's Pharmacy
//**************************************************************

// In String form, A PRMessage consists of a message tag 
// (see below) indicating what kind of message it is
// followed by a list of strings separated by  |  
// 
// Examples:  LOGIN|zilc1001|zilc1001|c
//            LOGIN_OK|1001|Joseph|Zilch|c
//            PR|1001|3121|1|MAY-20-2002|0900|
//            PR_NON some message

import java.io.*;
import java.util.StringTokenizer;

public class PRMessage implements Serializable
{
   // Server Message Tags
   public static final int SERVER_PR = 1; // PRServer down or error
   public static final int SERVER_DB = 2; // DBServer down or error
   public static final String CREATOR = "schi3008";

   // Login message tags
   public static final int LOGIN     = 10; // request login
   public static final int LOGIN_OK  = 11; // login succeeded
   public static final int LOGIN_NOK = 12; // login failed
   public static final int LOGIN_SUS = 13; // account suspended

   // Refill message tags
   public static final int PR     = 20; // request refill
   public static final int PR_OK =  21;  // request succeeded
   public static final int PR_EXP = 22; // prescription expired
   public static final int PR_NON = 23; // no more refills
   public static final int PR_INV = 24; // invalid prescription number
   public static final int PR_DUP = 25; // already requested
   public static final int PR_UPDT = 26; // update a refill request

   // List Refill Request message tags
   public static final int LR     = 30; // request refill request list
   public static final int LR_OK = 31; // request refill list retrieved
   public static final int LR_NON = 32; // no recent refill requests

   // List Prescription message tags
   public static final int LP     = 40; // request prescription list
   public static final int LP_OK  = 41; // prescription list retrieved
   public static final int LP_NON = 42; // no recent prescriptions

   private int tag;
   private String [] message;

   public PRMessage(int theTag, String [] parts)
   {
      message = new String[parts.length];
      tag = theTag;
      for( int i=0;i<parts.length; i++)
      {  
         message[i] = parts[i];
      }
   }

   public PRMessage(String m)
   {
     StringTokenizer parts = new StringTokenizer(m, "|");
     String tagstr= parts.nextToken();
     tag = new Integer( tagstr ).intValue();
     message = new String[parts.countTokens()];
     int last = parts.countTokens(); 
     for(int i = 0; i < last; i++)
     {   
         message[i] = parts.nextToken();
     } 
   }
        
   public String toString()
   {
      Integer t = new Integer(tag);
      String temp = new String(t.toString());
      for( int i=0; i< message.length; i++)
         temp = temp + "|" + message[i];
      return temp;
   }

   public int getTag()
   {
     return tag;
   }

   public String [] getMessage ()
   {
     return message;
   }

} // end PRMessage
