//********************************************************
//         File: PRServer.java
//       Author: HGG 
//         Date: January 2000
//     Modified: May 2002
//     Computer: PCs and KUNet
//     Compiler: jdk1.1.8 and jdk 1.2
//      Purpose: To demonstrate the development of the web server 
//               for Fred's Web Page Activities
//               This version sets up the PRServer on the machine 
//               pooh.kutztown.edu or localhost and waits for 
//               clients to send information.  Each 
//               request from a client spawns a PRServerConnection
//               to handle that client.  The client sends sample
//               string messages to the PRServerConnection in
//               serialized form.  The class of the message should
//               implement serialializable and the method toString.
//
//      Compile: javac PRServer.java
//      Execute: On Suns
//               java PRServer port_number
//               or
//               java PRServer port_number > PRServer.log &
//
//               In DOS window
//               java PRServer port_number
//
//       Output: In DOS Check MS Dos window for 
//               output of the customer selected.
//    Reference: van der Linden's book on Just Java 2 for the
//               simple example server2.java
//********************************************************

import java.io.*;
import java.net.*;

public class PRServer 
{
   public static void main(String args[]) throws IOException 
   {
       int q_len = 6; // length of queue - reality?
       int port;
       Socket sock;
       if(args.length != 1)
       {
          System.out.println("Usage: java PRServer port_number");
          return;
       }
       else
          port = Integer.parseInt(args[0]);

       ServerSocket servsock = new ServerSocket(port, q_len);
       System.out.println("Refill Server up and running\n");
       while (true) // infinite running loop
       {
         // wait for the next client connection
         sock=servsock.accept();
         new PRServerConnection( sock ).start();
       }   
   }
}
