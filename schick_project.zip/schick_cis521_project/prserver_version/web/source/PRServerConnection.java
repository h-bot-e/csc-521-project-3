//********************************************************
//         File: PRServerConnection.java
//       Author: HGG 
//         Date: January 2000
//     Modified: 12/03/03 - Joe Schick
//     Computer: PCs and KUNet
//     Compiler: java 1.4
//      Purpose: The server object for a client connection
//               to Fred's Pharmacy 
//********************************************************

import java.io.*;
import java.net.*;
import java.util.*;
import java.math.*;

// One PRServer Connection object is created
// for each client

public class PRServerConnection extends Thread 
{
  private Socket sock;
  private ObjectOutputStream oos;
  private ObjectInputStream  ois;
  private PRBusiness business;

  public PRServerConnection(Socket s) 
   { 
     sock = s;
     business = new PRBusiness();
   }
  public void run()
   {
     System.out.println("Thread running:"+currentThread() );

     // get the I/O streams for the socket
     try 
      {
        oos  = new ObjectOutputStream( sock.getOutputStream() );
        ois  = new ObjectInputStream ( sock.getInputStream() );
      }
     catch (IOException e)
      {
        System.out.println("No Object streams in PRServerConnection Thread");
        e.printStackTrace();
        return;
      }

     String c = new String();
     try
      {
        c =  (String)ois.readObject();
        while(!c.equals("Done"))
         {
           System.out.println("Received message: " + c);

           c = business.processMessage(c);
           System.out.println("Return Message: " + c);

           oos.writeObject(c);
           oos.flush();
           c = (String) ois.readObject();
         }
        System.out.println("In Thread :"+currentThread() );
        System.out.println("Done received: " + c);
      }
     catch(IOException ioe)
      {
        System.out.println(ioe);
      }
     catch(ClassNotFoundException ioe)
      {
        System.out.println(ioe);
      }
     try
      {
        sock.close();
      }
     catch(IOException ioe)
      {
        ioe.printStackTrace();
      }
   } 
}
