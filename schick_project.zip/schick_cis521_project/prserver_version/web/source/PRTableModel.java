//********************************************************************************
//         File: PRTableModel.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: This abstract class provides a base class for all table models 
//               used to display data associated with Fred's Pharmacy.
//
//********************************************************************************

import java.util.Vector;
import javax.swing.*;
import javax.swing.table.*;


public abstract class PRTableModel extends AbstractTableModel
{
  private Vector data;
  private String headers[];
  private Class colTypes[];
  private int columnCount;
   
  public PRTableModel(String[] colHeaders, Class[] columnTypes, int colCount)
   {
     data = new Vector();
     headers = colHeaders;
     colTypes = columnTypes;
     setColumnCount(colCount);
   }

  /********* Start implementation of TableModel Interface ***********/

  public int getRowCount()
   {
     return data.size();
   }
  public int getColumnCount()
   {
     return columnCount;
   }
  public String getColumnName(int c)
   {
     return headers[c];
   }
  public Class getColumnClass(int c)
   {
     return colTypes[c];
   }
  public Object getValueAt(int row, int col)
   {
     return ((PRTableObject)data.elementAt(row)).getProperty(col);
   }
  
  /********* End implementation of TableModel Interface ***********/

  public abstract void getData(Long customerNo);
  
  protected void clearTable()
   {
     data.clear();
   }
  protected void addObject(Object obj)
   {
     data.add(obj);
   }
  protected Object getObject(int row)
   {
     return data.elementAt(row); 
   }
  protected void setColumnCount(int count)
   {
     columnCount = count;
   }
  
}