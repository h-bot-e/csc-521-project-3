//********************************************************************************
//         File: PRTableObject.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: This interface includes the methods that an object needs to 
//               implement in order for its data to be easily extracted for
//               used in a JTable. 
//
//********************************************************************************

public interface PRTableObject
{
  public String[] getHeaders();
   
  public Class[] getPropertyTypes();
   
  public int getPropertyCount();
   
  public void setProperty(int num, String value);

  public String getProperty(int num);
}