//********************************************************************************
//         File: PharmacyInterface.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: This class controls which GUI is presented to a user after they 
//               have successfully logged in.
//
//********************************************************************************

import javax.swing.*;
import java.awt.*;


public class PharmacyInterface extends JApplet implements LoginListener
{
  private Font appFont = new Font("Serif", Font.PLAIN, 12);
  private FontMetrics metrics = getFontMetrics(appFont);
  private LoginPanel lp;
  private JPanel loginPane;
  private JPanel msgPane;
  private JLabel msg;
              

  public void init()
    {
      setFont(appFont);
      setForeground(Color.white);
      setBackground(Color.white);
      Container content = getContentPane();
      content.setLayout(new BorderLayout());
       
      lp = new LoginPanel();

      loginPane = new JPanel();
      loginPane.setBackground(Color.white);
      loginPane.add(lp);

      msgPane = new JPanel();
      msgPane.setBackground(Color.white);
      msg = new JLabel("");
      msgPane.add(msg);
      
      content.add("Center", loginPane);
      lp.addLoginListener(this);
    }
  public void loginAttempted(LoginEvent le)
    {
      Object source = le.getSource();

      if(source == lp)
        {
          Container content = getContentPane();
          User usr;
          if(le.getLogin().getStatus() == Login.GRANTED)
            {
              usr = lp.getUser();
              content.removeAll();
              
              if(usr.getUserType().equals("c") || usr.getUserType().equals("C"))
                {
                  content.add("Center", new CustomerInterface(lp.getUser()));
                }
              else if(usr.getUserType().equals("d") || usr.getUserType().equals("D"))
                {
                  msg.setText("Online access for doctors is not supported at this time.");
                  content.add("Center", msgPane);
                }
              else if(usr.getUserType().equals("e") || usr.getUserType().equals("E"))
                {
                  msg.setText("Online access for employees is not supported at this time.");
                  content.add("Center", msgPane);
                }
              else if(usr.getUserType().equals("s") || usr.getUserType().equals("S"))
                {
                  msg.setText("Your account is suspended. Please call your local Fred's Pharmacy.");
                  content.add("Center", msgPane);
                }
              else
                {
                  msg.setText("There is a problem with your account. Please contant your local "
                              + "Fred's Pharmacy.");
                  content.add("Center", msgPane);
                }
              
              content.validate();
            }
          return;
        }
    }
}