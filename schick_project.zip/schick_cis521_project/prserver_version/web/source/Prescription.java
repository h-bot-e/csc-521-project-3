//********************************************************************************
//         File: Prescription.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To represent a prescription in a JTable. This class provides 
//               methods which simplify the extraction of prescription related
//               data for placement in a JTable environment.
//
//********************************************************************************

import java.util.*;

public class Prescription implements PRTableObject
{
  private static final int PROP_COUNT = 8;
  public static final int PRESCRIPTION_NO = 0;
  public static final int DRUG_NAME = 1;
  public static final int DOCTOR = 2;
  public static final int INSTRUCTIONS = 3;
  public static final int PRESCRIPTION_DATE = 4;
  public static final int QUANTITY = 5;
  public static final int REFILLS_REMAINING = 6;
  public static final int EXP_DATE = 7;

  private String prescriptionNo;
  private String drug;
  private String doctor;
  private String instructions;
  private String date;
  private String quantity;
  private String refillsLeft;
  private String expDate;
  private static String[] propNames = new String[]{"Prescription No.", "Drug", 
                                    "Doctor", "Instructions", "Prescription Date",
                                    "Quantity", "Refills Left", "Expiration Date"};
  private static Class[] propTypes = new Class[]{String.class, String.class, 
                                     String.class, String.class, String.class,
                                     String.class, String.class, String.class};
  

  public Prescription()
   {
     for(int i=0;i < PROP_COUNT;i++)
       {
         setProperty(i, new String(""));
       }
   }
  public Prescription(String data)
   {
     StringTokenizer p = new StringTokenizer(data, "|");

     for(int i=0;i < PROP_COUNT;i++)
       {
         setProperty(i, new String(""));
       }

     for(int i=0;p.hasMoreElements() && i < PROP_COUNT;i++)
       {
         setProperty(i, p.nextToken());
       }
   }
  public String[] getHeaders()
   {
     return propNames;
   }
  public Class[] getPropertyTypes()
   {
     return propTypes;
   }
  public int getPropertyCount()
   {
     return Prescription.PROP_COUNT;
   }
  public void setProperty(int num, String value)
   {
     switch(num)
       {
         case PRESCRIPTION_NO:    setPrescriptionNo(value);
                                  break;
         case DRUG_NAME:          setDrug(value);
                                  break;
         case DOCTOR:             setDoctor(value);
                                  break;
         case INSTRUCTIONS:       setInstructions(value);
                                  break;
         case PRESCRIPTION_DATE:  setDate(value);
                                  break;
         case QUANTITY:           setQuantity(value);
                                  break;
         case REFILLS_REMAINING:  setRefillsLeft(value);
                                  break;
         case EXP_DATE:           setExpDate(value);
                                  break;
         default:                 System.err.println("Unknown Prescription property: " + num);
                                  break;
       }
   }
  public String getProperty(int num)
   {
     switch(num)
       {
         case PRESCRIPTION_NO:    return getPrescriptionNo();
                                 
         case DRUG_NAME:          return getDrug();
                                  
         case DOCTOR:             return getDoctor();
                                  
         case INSTRUCTIONS:       return getInstructions();
                                  
         case PRESCRIPTION_DATE:  return getDate();
                                  
         case QUANTITY:           return getQuantity();
                                  
         case REFILLS_REMAINING:  return getRefillsLeft();
                                  
         case EXP_DATE:           return getExpDate();
                                  
         default:                 System.err.println("Unknown Prescription property: " + num);
                                  return new String("");
                                  
       }
   }
  public void setPrescriptionNo(String num)
   {
     prescriptionNo = num;
   }
  public String getPrescriptionNo()
   {
     return prescriptionNo;
   } 
  public void setDrug(String d)
   {
     drug = d;
   }
  public String getDrug()
   {
     return drug;
   } 
  public void setDoctor(String d)
   {
     doctor = d;
   }
  public String getDoctor()
   {
     return doctor;
   } 
  public void setInstructions(String i)
   {
     instructions = i;
   }
  public String getInstructions()
   {
     return instructions;
   } 
  public void setDate(String dt)
   {
     date = dt;
   }
  public String getDate()
   {
     return date;
   } 
  public void setQuantity(String q)
   {
     quantity = q;
   }
  public String getQuantity()
   {
     return quantity;
   } 
  public void setRefillsLeft(String rl)
   {
     refillsLeft = rl;
   }
  public String getRefillsLeft()
   {
     return refillsLeft;
   } 
  public void setExpDate(String exp)
   {
     expDate = exp;
   }
  public String getExpDate()
   {
     return expDate;
   } 
  public String toString()
   {
     return prescriptionNo + "|" + drug + "|" + doctor + "|" + instructions + "|" 
            + date + "|" + quantity + "|" + refillsLeft + "|" + expDate;
   }
}