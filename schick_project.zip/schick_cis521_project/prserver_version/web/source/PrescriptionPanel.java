//********************************************************************************
//         File: PrescriptionPanel.java
//       Author: Joe Schick
//         Date: 12/03/03
//     Computer: PCs and Suns
//      Purpose: To provide a GUI which allows a customer of Fred's Pharmacy to 
//               view their refillable prescription, and view their current refill
//               requests.
//
//********************************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class PrescriptionPanel extends JPanel implements ActionListener
{
  private long custNo;
  private JTable prescriptionTable;
  private JTable refillRequestTable;
  private PrescriptionTableModel pModel;
  private RefillRequestTableModel rModel;
  private JScrollPane refillRequestPane;  // for requested refills table
  private JScrollPane prescriptionPane;   // for prescription table
  private JPanel prescriptionPanel;
  private JPanel refillRequestPanel;
  private JButton refreshPrescription;
  private JButton refreshRefillRequest;
  private JPanel refreshPrescriptionPanel;
  private JPanel refreshRefillRequestPanel;
  private JLabel prescriptionLabel;
  private JLabel refillRequestLabel;
  private RefillPanel refillPanel;

  public PrescriptionPanel(long customerNo)
    {
      super();
      setLayout(new GridLayout(3, 1, 10, 0));
      setBackground(Color.white);
      setCustNo(customerNo); 
      prescriptionPanel = new JPanel();
      prescriptionPanel.setLayout(new BorderLayout());
      prescriptionPanel.setBackground(new Color(202, 228, 255));
      refillRequestPanel = new JPanel();
      refillRequestPanel.setLayout(new BorderLayout());
      refillRequestPanel.setBackground(new Color(202, 228, 255));
      refreshPrescriptionPanel = new JPanel();
      refreshPrescriptionPanel.setBackground(new Color(202, 228, 255));
      refreshRefillRequestPanel = new JPanel();
      refreshRefillRequestPanel.setBackground(new Color(202, 228, 255));
      refreshPrescription = new JButton("Refresh");
      refreshRefillRequest = new JButton("Refresh");
      refillPanel = new RefillPanel(getCustNo());
      prescriptionLabel = new JLabel("Prescriptions");
      refillRequestLabel = new JLabel("Requested Refills");
    
      // Set up prescription table
      pModel = new PrescriptionTableModel();
      prescriptionTable = new JTable(pModel);
      prescriptionTable.setBackground(Color.white);
      prescriptionPane = new JScrollPane(prescriptionTable);
      pModel.getData(new Long(customerNo));

      // Set up refill table
      rModel = new RefillRequestTableModel();
      refillRequestTable = new JTable(rModel);
      refillRequestTable.setBackground(Color.white);
      refillRequestPane = new JScrollPane(refillRequestTable);
      rModel.getData(new Long(customerNo));

      refreshPrescription.addActionListener(this);
      refreshRefillRequest.addActionListener(this);

      refreshPrescriptionPanel.add(refreshPrescription);
      prescriptionPanel.add("North", prescriptionLabel);
      prescriptionPanel.add("Center", prescriptionPane);
      prescriptionPanel.add("South", refreshPrescriptionPanel);

      refreshRefillRequestPanel.add(refreshRefillRequest);
      refillRequestPanel.add("North", refillRequestLabel);
      refillRequestPanel.add("Center", refillRequestPane);
      refillRequestPanel.add("South", refreshRefillRequestPanel);

      add(prescriptionPanel);
      add(refillRequestPanel);
      add(refillPanel);
    }
  public void actionPerformed(ActionEvent ae)
    {
      Object source = ae.getSource();
 
      if(source == refreshPrescription)
        { 
          refreshPrescription.setEnabled(false);
          pModel.getData(new Long(getCustNo()));
          refreshPrescription.setEnabled(true);
        }
      else if(source == refreshRefillRequest)
        {
          refreshRefillRequest.setEnabled(false);
          rModel.getData(new Long(getCustNo()));
          refreshRefillRequest.setEnabled(true);
        }
    }
  private void setCustNo(long no)
    {
      custNo = no;
    }
  private long getCustNo()
    {
      return custNo;
    }
}