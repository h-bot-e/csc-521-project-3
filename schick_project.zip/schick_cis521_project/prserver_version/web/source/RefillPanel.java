//********************************************************************************
//         File: RefillPanel.java
//       Author: Joe Schick
//         Date: 12/03/03
//     Computer: PCs and Suns
//      Purpose: To provide a form which allows a customer of Fred's Pharmacy to 
//               make a new refill request.
//
//********************************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.lang.*;
import java.util.*;
import java.util.StringTokenizer;


public class RefillPanel extends JPanel 
             implements ActionListener, ItemListener, KeyListener
{
  private long custNo;
  private JTextField prescriptionID;
  private JComboBox store;  
  private JComboBox date;
  private JComboBox time;
  private JLabel status;
  private JButton submitButton;
  private JLabel prescriptionLabel;
  private JLabel storeLabel;
  private JLabel dateLabel;
  private JLabel timeLabel;
  private JLabel statusLabel;
  private JLabel requestRefillLabel;
  private JPanel p1;
  private JPanel p2;

  // the following are used in later development
  private String refillData;
  private String pickupDate;
  private boolean connected = false;

  private String [] stores =
   { "Select a store for pick-up", "Fogelsville", "Breinigsville"};

  private String [] months = 
   { "January", "February", "March", "April", "May", "June",
     "July", "August", "September", "October", "November", "December"};

  private String [] days =
   { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday",
     "Friday", "Saturday"};
  
  public RefillPanel(long customerNo)
    {
      super();
      setLayout(new BorderLayout());
      setBackground(new Color(202, 228, 255));
      setCustNo(customerNo); 
      p1 = new JPanel(new GridLayout(6,2,5,5));
      p1.setBackground(new Color(202, 228, 255));
      p2 = new JPanel(new FlowLayout());
      p2.setBackground(new Color(202, 228, 255));
      prescriptionID = new JTextField(30);
      store = new JComboBox();  
      date = new JComboBox();
      time = new JComboBox();
      status = new JLabel(" Fill Form and press Submit Request");
      submitButton = new JButton("Submit Request");
      prescriptionLabel = new JLabel("Prescription Number");
      storeLabel  = new JLabel("Pick-Up Store");
      dateLabel   = new JLabel("Pick-Up Date");
      timeLabel   = new JLabel("Time");
      statusLabel = new JLabel("Status ");
      requestRefillLabel = new JLabel("Request a Refill");

      add(p1, "Center");
      add(p2, "South");
      add(requestRefillLabel, "North");

      p1.add(prescriptionLabel);
      p1.add(prescriptionID);
      prescriptionID.setBackground(Color.white);
      prescriptionID.requestFocus();

      p1.add(storeLabel);
      p1.add(store);
      for(int i=0; i < stores.length; i++)
         store.addItem(stores[i]);

      p1.add(dateLabel);
      p1.add(date);

      p1.add(timeLabel);
      p1.add(time);

      p1.add(statusLabel);
      p1.add(status);
      status.setFont(new Font("Monospaced", Font.BOLD, 12) );
      status.setBackground(Color.white);

      p2.add(submitButton);

      // used for dates
      GregorianCalendar  d = new GregorianCalendar();
      int month = d.get(Calendar.MONTH);
      int day   = d.get(Calendar.DATE);
      int year   = d.get(Calendar.YEAR);
      int day_name = d.get(Calendar.DAY_OF_WEEK)-1;

      date.addItem("Select a date for pick-up");

      // This needs to be fixed so it wraps
      for(int i = 0; i <= 4; i++)
      {  
         String s1 = new String( days[(day_name)] + ", " 
                            + months[d.get(Calendar.MONTH)] + " " 
                            + (d.get(Calendar.DATE)) + ", " 
                            + d.get(Calendar.YEAR));
         date.addItem(s1);
         day_name = (day_name >= 6 ? 0 : day_name+1);
         d.set(d.get(Calendar.YEAR),d.get(Calendar.MONTH),
               d.get(Calendar.DATE)+1);
      }

      time.addItem("Select time for pick-up");
      time.addItem(" 9:00 AM");
      time.addItem("10:00 AM");
      time.addItem("11:00 AM");
      time.addItem("12:00 PM");
      time.addItem(" 1:00 PM");
      time.addItem(" 2:00 PM");
      time.addItem(" 3:00 PM");
      time.addItem(" 4:00 PM");
      time.addItem(" 5:00 PM");
      time.addItem(" 6:00 PM");
      time.addItem(" 7:00 PM");
      time.addItem(" 8:00 PM");

      // Register TextFields and Buttons with ActionListener
      prescriptionID.addActionListener(this);
      submitButton.addActionListener(this);

      // Register ComboBoxes with ItemListener
      store.addItemListener(this);  
      date.addItemListener(this);
      time.addItemListener(this);

      // Register components with KeyListener
      prescriptionID.addKeyListener(this);
      store.addKeyListener(this);  
      date.addKeyListener(this);
      time.addKeyListener(this);
      submitButton.addKeyListener(this);
    }

  //*****************************************************
  // Implement actionPerformed() for ActionListener
  //*****************************************************
  public void actionPerformed(ActionEvent event)
   {
      Object source = event.getSource();

      if(source == prescriptionID)
      {  
         status.setText("Select Store");
         store.requestFocus();
         return;
      }

      if(source == submitButton)
      {        
         int check = -1; 

         // check if form is completed
         if(prescriptionID.getText().equals(""))
         {
            status.setForeground(Color.red);
            status.setText(" Please enter a prescription number");
            prescriptionID.requestFocus();
            return;
         }

         if(((String)store.getSelectedItem()).equals("Select a store for pick-up"))
         {
            status.setForeground(Color.red);
            status.setText(" Please select a pick-up store");
            store.requestFocus();
            return;
         }

         if(((String)date.getSelectedItem()).equals("Select a date for pick-up"))
         {
            status.setForeground(Color.red);
            status.setText(" Please select a date for pick-up");
            date.requestFocus();
            return;
         }

         if(((String)time.getSelectedItem()).equals("Select time for pick-up"))
         {
            status.setForeground(Color.red);
            status.setText(" Please select a time for pick-up");
            time.requestFocus();
            return;
         }

         // form is complete so 
         // disable more requests until this one handled
         submitButton.setEnabled(false); 

         // put in a call to PRServer
         status.setForeground(Color.blue);
         status.setText("Request submitted.");
        
         check = ClientActivities.requestRefill(new Long(getCustNo()), prescriptionID.getText(), 
                                        String.valueOf(store.getSelectedIndex()), 
                                        (String)date.getSelectedItem(), (String)time.getSelectedItem());  
         decode(check);
         
         // clear form and re-enable submit button
         prescriptionID.setText("");
         // assume store, date and time same for next one, so ...
         //store.select(0);  
         //date.select(0);
         //time.select(0);
         prescriptionID.requestFocus();
         submitButton.setEnabled(true);
      }
   }

  //*****************************************************
  // Decode status returned from ClientActivities.requestRefill()
  //*****************************************************
   
  private void decode(int refillStatus)
   {
     switch(refillStatus)
      {
        case ClientActivities.PR_OK: 
          status.setText("Request submitted.");
          break;
        case ClientActivities.PR_EXP: 
          status.setText("Prescription expired.");
          break;
        case ClientActivities.PR_NON: 
          status.setText("No more refills left.");
          break;
        case ClientActivities.PR_INV: 
          status.setText("Invalid prescription number.");
          break;
        case ClientActivities.PR_DUP: 
          status.setText("A refill has already been requested.");
          break;
        default: 
          status.setText("Error processing request. Please try again.");
          break;
      }
   } // end decode  
   
  //*****************************************************
  // Other listener actions
  //*****************************************************

  // Implement itemStateChanged() for ItemListener
  public synchronized void itemStateChanged(ItemEvent event)
   {
      Object source = event.getSource();

      if(event.getStateChange() == ItemEvent.SELECTED)
      {
         if(source == store)
         {
            ;
         }

         if(source == date)
         {
            ;
         }

         if(source == time)
         {
            ;
         }
      }
   }
 
  public void keyReleased(KeyEvent event) {}

  public void keyPressed(KeyEvent event) 
   {
      ActionEvent ae = new ActionEvent(event.getSource(), 
                            ActionEvent.ACTION_PERFORMED, 
                            submitButton.getActionCommand());

      if(event.getKeyCode() == KeyEvent.VK_ENTER)
      {
        if(event.getSource() == submitButton)
           submitButton.dispatchEvent(ae);

        else if(event.getSource() == time)
           submitButton.requestFocus();

        else if(event.getSource() == prescriptionID)
        {
           event.getComponent().transferFocus();
           prescriptionID.select(0,0);
        }
        else
           event.getComponent().transferFocus();
      }
   }

  public void keyTyped(KeyEvent event) {}
 
 
  private void setCustNo(long no)
    {
      custNo = no;
    }
  private long getCustNo()
    {
      return custNo;
    }
}
