//********************************************************************************
//         File: RefillRequestTableModel.java
//       Author: Joe Schick
//         Date: 11/26/03
//     Computer: PCs and Suns
//      Purpose: To provide a JTable table model for displaying refill requests.
//
//********************************************************************************

import java.util.Vector;

public class RefillRequestTableModel extends PRTableModel
{
  private static RefillRequest r = new RefillRequest();
 
  public RefillRequestTableModel()
   {
     super(r.getHeaders(), r.getPropertyTypes(), r.getPropertyCount());
   }
  public void getData(Long customerNo)
   {
     Vector newRefillRequests = new Vector();

     newRefillRequests = ClientActivities.getRefillRequests(customerNo);

     clearTable();

     while(!newRefillRequests.isEmpty())
       {
         addObject((RefillRequest)newRefillRequests.remove(0));
       }

     fireTableDataChanged();
   }
}